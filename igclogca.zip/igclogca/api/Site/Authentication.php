<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site;
//
use Core\Helpers\Permission as Permission;



/**
 * Description of Authentication
 *
 *  This class is to add authentication permission to modules and sub modules
 * 
 * 
 * @author kms
 */
class Authentication Extends Permission{
    //put your code here
    private $_auth_schema = [
        "ConstAdmin"=>["loggedin"=>"loggedin"]
    ];
    
    private static $_instance = null;
    /**
     * 
     * @return type
     */
    public static function get_instance(){
        if(!isset(self::$_instance)){
           self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    
    /**
     * 
     * @param type $modname
     */
    public static function check_authentication($modname){
         $obj = self::get_instance();
         $obj->check_authentication_single(strtolower($modname));
    }
    /**
     * 
     */
    function __construct() {
        $this->updateSchema($this->_auth_schema);
    }
    /**
     * 
     * @param type $modname
     */
    private function check_authentication_single($modname){
        $this->check_auth($modname);
    }
    
  
    
}
