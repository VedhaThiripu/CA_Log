<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site\Controller;

use Site\Model\Consttable as const_table;
use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;
use Core\Helpers\Data as Data;
use Core\Helpers\Session as Session;
use Core\Helpers\Zldap as Zldap;
use Core\Helpers\General as General;



/**
 * Description of Auth
 *
 * @author kms
 */
class Auth Extends Controller {
    
    private $_roles = [];

    
    
   
    //put your code here
    public function login() {
		
        $ICNO     = Data::post_data("userid", "STRING");
        $password = Data::post_data("password", "STRING");		
      
        if (strlen($ICNO) < 1) {
            trigger_error("Please Enter userid ", E_USER_ERROR);
        }
        if (strlen($password) < 1) {
            trigger_error("Please Enter Password ", E_USER_ERROR);
        }
		
		if($ICNO =="test" && $password=="1234"){
			  $obj = $this->update_login($ICNO);
			   $this->suceess_output($obj);
		}else{
			trigger_error("Invalid Credentials ", E_USER_ERROR);        
		}
    }

    private function update_login($userid) {     
        // var_dump($data);
        $this->update_session($userid);
        $obj           = new \stdClass();
        $obj->name     = $userid;
        $obj->userid    = Session::get("userid");     
        $obj->timeout  = $this->getSessionRemainingTime();
        return $obj;
    }

    private function update_session($userid) {
        Session::start();
        Session::set("userid", $userid);
        Session::set("LOGGED_IN", 1);
        Session::set("USERNAME",$userid);
		Session::set("LOGGED_IN_TIME", time());
        // 
    }

   
    /**
     *  returns the session remaining with computing session maximum time 
     * 
     * 
     */
    private function getSessionRemainingTime() {
        $logged_in_time = Session::get("LOGGED_IN_TIME");
        $max_time       = $logged_in_time + (60 * 60); // seconds
        $remaining_time = $max_time - time();
        //
        // echo "session login time =" .  $logged_in_time . "    remiang time =  " . $remaining_time;
        // if the ramining time is negatice then sign out 
        if ($remaining_time < 0) {
            $this->sessionKill();
            \CustomErrorHandler::handle_authentication_function();
            return 0;
        } else {
            return $remaining_time; // round(floatval($remaining_time / ( 60)),1);
        }
    }

    /** gets the information and deploy it to react about login  information */
    public function showMe() {
        Session::start();
        $userid = Session::get("USERNAME");
        if ($userid != null || strlen($userid) > 1) {
            $obj           = new \stdClass();
            $obj->name     = Session::get("userid");           
            $obj->timeout  = $this->getSessionRemainingTime();
            $this->suceess_output($obj);
        } else {
            \CustomErrorHandler::handle_authentication_function();
        }
    }

    /**
     * 
     */
    public function refreshSession() {
        Session::start();
        $userid = Session::get("userid");       
        $this->sessionKill();
        $this->update_session($userid);
        $this->showMe();
    }

    private function sessionKill() {
        Session::start();
        Session::stop();
    }

    public function logout() {
        $this->sessionKill();
        $obj      = new \stdClass();
        $obj->msg = "logged out successfully";
        $this->suceess_output($obj);
    }

   
}
