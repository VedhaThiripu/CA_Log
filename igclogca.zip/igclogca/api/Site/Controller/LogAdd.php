<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site\Controller;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;
use Core\Helpers\Data as Data;
use Core\Helpers\Session as Session;
use Core\Helpers\Zldap as Zldap;
use Core\Helpers\General as General;
// site helpers
use Site\Helpers\LogAddHelper as LogHelper;

/**
 * Description of Auth
 *
 * @author kms
 */
class LogAdd Extends Controller {

    CONST SCHEMA = "log__infotable";

    private function insert_loger($id) {
        $cat = Data::post_data("category", "STRING");
        $path = Data::post_data("file_path", "STRING");
        LogHelper::extract_insert_log($path, $id, $cat);
    }

    private function check_log_file_type() {
        $cat = Data::post_data("category", "STRING");
        $path = Data::post_data("file_path", "STRING");
        $line = LogHelper::read_first_line($path);
        $data = null;
        switch ($cat) {
            case "CRON":
               // $data = LogHelper::extract_cron($line);
                 $data = [""];
                break;
            case "DNS":
                // $data = LogHelper::extract_dns($line);
                $data = [""];
                break;
            case "AUDIT":
                $data = LogHelper::extract_audit($line);
                break;
            case "MSG":
            //$data = LogHelper::extract_message($line);                
            //break;
            case "TIMESTAMP":
            case "HARDSERVER":
            case "RASERVER":
            case "BOOT":
            case "SECURE":
            case "FIREWALL":
            case "OCSP":
                $data = [""];
                break;
            default:
                break;
        }
        if ($data == null && count($data) < 1) {
            \CustomErrorHandler::triger_error("Invalid Log Format.Please check");
        }
    }

    private function check_log_file() {
        $path = Data::post_data("file_path", "STRING");
        if (strlen($path) < 3) {
            \CustomErrorHandler::triger_error("Please Enter valid File path");
        } else if (!file_exists($path)) {
            \CustomErrorHandler::triger_error("File Does not exists at path");
        }/* else if (is_file($path)){            
          \CustomErrorHandler::triger_error("It is not a file");
          } */ else {
            $this->check_log_file_type();
            // start processing the first line of file and get the data
        }
    }

    private function check_cat() {
        $cat = Data::post_data("category", "STRING");
        if (!LogHelper::check_cat($cat)) {
            \CustomErrorHandler::triger_error("Invalid Categeory");
        }
    }

    //insert_log
    public function insert_log() {
        $this->checkRequestType("POST");
        ini_set('max_execution_time', '0');
        //$this->accessControl();
        $this->check_cat();
        $this->check_log_file();
        $model = new Model(self::SCHEMA);
        $data = $model->insertwithdata($this->_post);
        //  $data = [];
        //  $data["id"] = 1;
        $this->insert_loger($data["id"]);
        $this->suceess_output($data);
    }

    /**
     * 
     */
    public function get_all() {
        $this->checkRequestType("GET");
        $model = new Model(self::SCHEMA);
        $data = $model->getDataFull([]);
        $this->suceess_output($data);
    }

    /**
     * 
     * @param type $param
     */
    public function get_one($param) {
        $this->checkRequestType("GET");        //   
        // $this->accessControl(["admin"]);
        $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        $model = new Model(self::SCHEMA);
        $data = $model->Where("ID=:id")->One()->getDataFull(["id" => $id]);
        $this->suceess_output($data);
        $this->suceess_output($data);
    }

    // delete_one
    public function delete_one($param) {
        $this->checkRequestType("DELETE");
        //   
        // $this->accessControl(["admin"]);
        $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        $model = new Model(self::SCHEMA);
        $model->deltewithid($id);
        $out = new \stdClass();
        $out->msg = "Deleted Successfully";
        $this->suceess_output($out);
        //$this->suceess_output($data);
    }

    /**
     * 
     */
    public function get_cats() {
        $this->checkRequestType("GET");
        //$this->accessControl();
        $cats = LogHelper::getcat();
        $out = [];
        foreach ($cats as $key => $title) {
            $db = new \stdClass();
            $db->key = $key;
            $db->value = $title;
            $out[] = $db;
        }
        $this->suceess_output($out);
    }

    /**
     * 
     * @param type $param
     */
    public function get_log($param) {
        $this->checkRequestType("GET");
        // $this->accessControl();    
        $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        $model = new Model();
        $data = $model->From("cron_log_table")->Where("infotable_id=:id")->getDataFull(["id" => $id]);
        $this->suceess_output($data);
    }

    public function get_details($param) {
        $this->checkRequestType();
        $db = new \stdClass();
        $db->site_title = defined("SITE_TITLE") ? SITE_TITLE : "Server Log Management";
        $db->site_logo = defined("SITE_LOGO") ? SITE_LOGO : "test.jpg";
		$db->site_footer = defined("SITE_FOOTER") ? SITE_FOOTER : "IGCAR";
        $this->suceess_output($db);
    }

}
