<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of HardServerLogHelper
 *
 * @author 91939
 */
class AideLogHelper {

    //put your code here

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    //
    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    private function extract_date_time() {
        if (!isset($GLOBALS["aide_cdate"]) && $this->get_value(1) == "timestamp:") {
            $GLOBALS["aide_cdate"] = $this->get_value(2);
            $GLOBALS["aide_ctime"] = $this->get_value(3);
        }
    }

    private function extract_total() {
        if (!isset($GLOBALS["tot_no_files"]) && $this->get_value(2) == "Total") {
            $GLOBALS["tot_no_files"] = preg_replace("/[^0-9]/", "", $this->get_value(5));
        }
    }

    private function extract_added() {
        if (!isset($this->_out["add_file"]) && $this->get_value(2) == "Added") {
            $this->_out["add_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));
        }
    }

    private function extract_changed() {
        if (!isset($this->_out["cha_file"]) && $this->get_value(2) == "Changed") {
            $this->_out["cha_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));
        }
    }

    private function extract_removed() {
        if (!isset($this->_out["rem_file"]) && $this->get_value(2) == "Removed") {
            $this->_out["rem_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));
        }
    }
    
    private function extract_data() {
        $this->_out["cdate"] =  $GLOBALS["aide_cdate"];
        $this->_out["ctime"] =  $GLOBALS["aide_ctime"];
        $this->_out["tot_no_files"] =  $GLOBALS["tot_no_files"];
        $this->_out["type"] = substr($this->get_value(0), 0, -1);
        if( $this->_out["type"]=="added"){
            $this->_out["add_file"] = $this->get_value(1);
        }
        if( $this->_out["type"]=="removed"){
            $this->_out["rem_file"] = $this->get_value(1);
        }
         if( $this->_out["type"]=="changed"){
            $this->_out["cha_file"] = $this->get_value(1);
        }
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        $this->_exploded_arr = explode(" ", $line);
        $this->_out = [];
        $this->extract_date_time();
        $this->extract_total();
        $type = $this->get_value(0);
        if($type=="added:" || $type=="removed:" || $type=="changed:"){
            $this->extract_data();
          //  var_dump($this->_exploded_arr);
          //  var_dump($this->_out);
        }
       
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}
