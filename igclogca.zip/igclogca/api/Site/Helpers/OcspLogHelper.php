<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of HardServerLogHelper
 *
 * @author 91939
 */
class OcspLogHelper {
    //put your code here
    
    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];
    //
    

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }
    
  
    
     
     private function extract_data() {
        $this->_out["cdate"] = $this->get_value(0);
        $this->_out["ctime"] = $this->get_value(1);
      //  $this->_out["deamon_id"] = $this->get_value(2);
       // $this->_out["server_name"] = $this->get_value(3);
       // $this->_out["log_type"] = str_replace(":","",$this->get_value(5));
        $msg_arr = array_slice($this->_exploded_arr, 2);
        $this->_out["remarks"] = implode(" ", $msg_arr);   
    }
    
    private function get_date(){
        $exploded = $this->get_value(0);
        $year = "20".substr($exploded, 0,2);
        $month = substr($exploded, 2,2);
        $day = substr($exploded, 4,2);
        return $year ."-" . $month ."-" . $day;
    }
    private function get_command() {
        //$exploded = array_values(array_filter(explode(" ", $this->get_value(3))));
        $exploded = preg_split("/\t+/", $this->get_value(3));
        $this->_out["argument"] = isset($exploded[1]) ? $exploded[1] :"";
        $cmd = isset($exploded[0]) ? trim($exploded[0]) :"";
       // echo "command =" . $cmd ."<br/>";
        if(strtolower($cmd)=="field"){
            $exploded_next = preg_split("/\t+/", $this->get_value(4));
            $part_cmd =  isset($exploded_next[0]) ? trim($exploded_next[0]) :"";
            $cmd = $cmd ." " . $part_cmd;
            //$this->_out["argument"] = "";
        }
       // echo "command N=" . $cmd ."<br/>";
        return $cmd;
    }
    
    private function start_processing() {        
        $this->_out["cdate"] = $this->get_date();
        $this->_out["ctime"] = $this->get_value(1);        
        $this->_out["cmd_id"] = intval($this->get_value(2));
        $this->_out["command"] = $this->get_command();
        $msg_arr = array_slice($this->_exploded_arr, 4);
        $this->_out["argument"] = $this->_out["argument"]  ." " . implode(" ", $msg_arr);  
    }
    
    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = array_values(array_filter(explode(" ", $line)));
        //
        $first_param = isset($this->_exploded_arr[0]) ? is_numeric($this->_exploded_arr[0]) :  false;
     
        if ($first_param==true) {
            $GLOBALS["tstart"] = 1;
        }
        $this->_out = [];
        if (isset($GLOBALS["tstart"])) {
            if($first_param===true){
                $GLOBALS["last_date"] = [$this->_exploded_arr[0], $this->_exploded_arr[1]];
            }else{
                array_splice($this->_exploded_arr, 0, 1,  $GLOBALS["last_date"]);
            }
           // var_dump($this->_exploded_arr);
            //if($first_param)
            $this->start_processing( $first_param );
            //var_dump($this->_out);
        }
        //
       // $this->common_data();
        //
      //  $this->get_paratmers_with_type();
       // var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }
}
