<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class MsgLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $month = $this->get_value(0);
        $month_number = date("n", strtotime($month));
        $day = $this->get_value(2);
        $time = $this->get_value(3);
        $year = date("Y");
        return [$year . "-" . $month_number . "-" . $day, $time];
    }
    
     private function common_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->_out["type"] = substr($this->get_value(5), 0, -1);
        $this->_out["server_name"] = $this->get_value(4);       
    }
    private function get_common_parameters() {
       $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["msg"] = implode(" ", $msg_arr); 
    }
    
    private function get_rsyslogd_parameters() {
        $this->_out["subtype"] = str_replace("[", "", $this->get_value(6));
        $this->_out["software"] = str_replace('software="', "", $this->get_value(7));
        $this->_out["software"] = str_replace('"', "", str_replace("'", "", $this->_out["software"]));
        $this->_out["swVersion"] = str_replace('swVersion="', "", $this->get_value(8));
        $this->_out["swVersion"] = str_replace('"', "", str_replace("'", "", $this->_out["swVersion"]));
        //
        $this->_out["x_pid"] = str_replace('x-pid=', "", $this->get_value(8));
        $this->_out["x_pid"] = str_replace('"', "", str_replace("'", "", $this->_out["x_pid"]));
        //
        $this->_out["x_info"] = str_replace('x-info="', "", $this->get_value(8));
        $this->_out["x_info"] = str_replace('"', "", str_replace("'", "", $this->_out["x_info"]));
        $msg_arr = array_slice($this->_exploded_arr, 11);
        $this->_out["remarks"] = implode(" ", $msg_arr);       
    }
    
    private function get_kernal_parameters() {
        $this->_out["subtype"] = substr($this->get_value(6), 0, -1);
         $msg_arr = array_slice($this->_exploded_arr, 7);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }
    
    
    private function get_paratmers_with_type() {
        switch ($this->_out["type"]) {
            case "rsyslogd": $this->get_rsyslogd_parameters();
                break;
            case "kernel": $this->get_kernal_parameters();
                break;
            case "journal" : $this->get_common_parameters();
                break;
            case "systemd" : $this->get_common_parameters();
                break;
            case "systemd-logind" : $this->get_common_parameters();
                break;
            case "auditd" : $this->get_common_parameters();
                break;
            default: $this->_out=[];
                break;
        }
    }
    
    
    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = explode(" ", $line);
        
        //
        $this->_out = [];
        //
        $this->common_data();
        //
        $this->get_paratmers_with_type();
        //var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  SYSCALL: Records a system call made by a process.
CRED_ACQ: Records the acquisition of a user credential.
CRED_DISP: Records the disposal of a user credential.
USER_START: Records the start of a user session.
USER_END: Records the end of a user session.
USER_LOGIN: Records a user login attempt.
USER_LOGOUT: Records a user logout event.
USER_AUTH: Records a user authentication event.
USER_ACCT: Records user account changes (e.g., password changes).
CONFIG_CHANGE: Records system configuration changes.
SYSTEM_RUNLEVEL: Records changes to the system runlevel (e.g., startup, shutdown).
SECCOMP: Records the use of the seccomp facility.
NETFILTER_CFG: Records changes to the netfilter configuration.
MAC_POLICY_LOAD: Records the loading of a MAC policy.
MAC_STATUS: Records the status of the MAC system.
ANOM_ABEND: Records an abnormal program termination.
ANOM_PROMISCUOUS: Records a change in network interface promiscuous mode.
ANOM_LOGIN_FAILURES: Records repeated failed login attempts.
 
 */

