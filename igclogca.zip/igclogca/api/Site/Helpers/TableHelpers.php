<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of TableHelpers
 *
 * @author 91939
 */
class TableHelpers {
    //put your code here
    CONST INFOTABLE = "infotable";
    CONST CRON = "cron_log_table";
    CONST DNS = "dns_log_table";
    CONST MSG = "messages_log_table";
    CONST AUDIT = "audit_log_table";
    const CRON_TABLE = "cron_table";
    const CRON_FILES = "cron_files";
    const TIMESTAMP = "timestamp_log";
    const HARDSERVER = "hardserver_log";
    const RASERVER = "raserver_log";
    const FIREWALL = "firewall_log";
    const SECURE = "secure_log";
    const BOOT = "boot_log";
    const OCSP = "ocsp_log";
}
