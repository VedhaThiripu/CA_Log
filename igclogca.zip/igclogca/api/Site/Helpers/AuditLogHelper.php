<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class AuditLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    private function get_date($timestamp) {
        return date('Y-m-d H:i:s', $timestamp);
    }

    private function get_time($timestamp) {
        return date('H:i:s', $timestamp);
    }

    private function get_common_data() {
        $pattern = '/^type=(\S+)\s+msg=audit\((\d+\.\d+):(\d+)\):\s+(.*)$/';
        $matches = [];
        if (preg_match($pattern, $this->_line, $matches)) {
            $this->_out["type"] = $matches[1]; // Extract type
            $timestamp = $matches[2]; // Extract timestamp
            // echo $timestamp;
            $this->_out["cdate"] = $this->get_date($timestamp);
            $this->_out["ctime"] = $this->get_time($timestamp);
            $this->_out["deamon_id"] = $matches[3]; // Extract sequence number
            //  $this->_out["msg"] = $msg = $matches[4]; // Extract message           
        } else {
            // echo "Unable to extract fields from log entry\n";
        }
    }

    private function get_value_equals($index_number) {
        $value = $this->get_value($index_number);
        $exploded = explode("=", $value);
        return isset($exploded[1]) ? $exploded[1] : "";
    }

    /**
     * 
     */
    private function get_proctitle_parameters() {
        $this->_out["proctitle"] = $this->get_value_equals(2);
    }

    private function get_syscall_parameters() {
        for ($i = 2; $i < count($this->_exploded_arr); $i++) {
            $value = $this->_exploded_arr[$i];
            $exploded = explode("=", $value);
            $index = isset($exploded[0]) ? $exploded[0] : "";
            if ($index == "exit") {
                $index = "exit_code";
            }else if ($index == "old-auid") {
                $index = "old_auid";
            }else if ($index == "old-ses") {
                $index = "old_ses";
            }else if ($index == "kind") {
                $index = "kind_field";
            }else if($index=="key"){
                $index = "key_file";
            }else if($index=="msg"){
                $new_value = str_replace("msg=","",$value);
                $exploded = explode("=",$new_value);
                $index = "op";
            }
            $val = isset($exploded[1]) ? $exploded[1] : "";
            $this->_out[$index] = $val;
        }
    }

    private function get_paratmers_with_type() {
        switch ($this->_out["type"]) {
            case "PROCTITLE": $this->get_proctitle_parameters();
                break;
            case "SYSCALL":
            case "PATH":
            case "USER_START":
            case "CRED_REFR":
            case "USER_LOGIN":
            case "CRED_DISP":
            case "USER_END":
            case "SERVICE_STOP":
            case "SERVICE_START":
            case "USER_ACCT":
            case "CRED_ACQ":
            case "LOGIN":
            case "EXECVE":
            case "USER_AUTH":
                
            case "USER_ROLE_CHANGE":
            case "AVC":
            case "USER_CHAUTHTOK":
            case "NETFILTER_CFG":
            case "EXECVE":
            case "CONFIG_CHANGE":
            case "ANOM_ABEND":
            case "ANOM_RBAC_INTEGRITY_FAIL":
            case "SECCOMP":                    
                $this->get_syscall_parameters();
                break;
            case "CROND" : $this->get_crond_parameters();
                break;
            default: break;
        }
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        $this->_line = $line;
        $this->_exploded_arr = explode(" ", $line);
        //
        $this->_out = [];
        $this->get_common_data();
        //var_dump($this->_out);
        if (isset($this->_out["type"])) {
            // other data with job type
            $this->get_paratmers_with_type();
            //
          //  var_dump($this->_out);
            // return 
            return $this->_out;
        } else {
            return [];
        }
        //var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  SYSCALL: Records a system call made by a process.
CRED_ACQ: Records the acquisition of a user credential.
CRED_DISP: Records the disposal of a user credential.
USER_START: Records the start of a user session.
USER_END: Records the end of a user session.
USER_LOGIN: Records a user login attempt.
USER_LOGOUT: Records a user logout event.
USER_AUTH: Records a user authentication event.
USER_ACCT: Records user account changes (e.g., password changes).
CONFIG_CHANGE: Records system configuration changes.
SYSTEM_RUNLEVEL: Records changes to the system runlevel (e.g., startup, shutdown).
SECCOMP: Records the use of the seccomp facility.
NETFILTER_CFG: Records changes to the netfilter configuration.
MAC_POLICY_LOAD: Records the loading of a MAC policy.
MAC_STATUS: Records the status of the MAC system.
ANOM_ABEND: Records an abnormal program termination.
ANOM_PROMISCUOUS: Records a change in network interface promiscuous mode.
ANOM_LOGIN_FAILURES: Records repeated failed login attempts.
 
 */

