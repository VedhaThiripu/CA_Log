<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of HardServerLogHelper
 *
 * @author 91939
 */
class RaServerLogHelper {
    //put your code here
    
    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }
    
  
    
     
     private function extract_data() {
        $this->_out["cdate"] = $this->get_value(0);
        $this->_out["ctime"] = $this->get_value(1);
      //  $this->_out["deamon_id"] = $this->get_value(2);
       // $this->_out["server_name"] = $this->get_value(3);
       // $this->_out["log_type"] = str_replace(":","",$this->get_value(5));
        $msg_arr = array_slice($this->_exploded_arr, 2);
        $this->_out["remarks"] = implode(" ", $msg_arr);   
    }
    
    private function check_date(){
        $first_param = explode("-", $this->get_value(0));
        return count($first_param)==3 ? true : false;
    }
    
   
    
    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
        
        //
        $this->_out = [];
        //
        if($this->check_date()){
            $this->extract_data();
           // var_dump($this->_exploded_arr);
           // var_dump($this->_out);
        }
        //
       // $this->common_data();
        //
      //  $this->get_paratmers_with_type();
       // var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }
}
