<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of HardServerLogHelper
 *
 * @author 91939
 */
class AideLogHelper {
    //put your code here
    
    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];
    //
    

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }
    
  
    
     
     private function extract_date_time() {
        if(!isset($this->_out["cdate"]) && $this->get_value(1)=="timestamp:"){
            $this->_out["cdate"] = $this->get_value(2);
            $this->_out["ctime"] = $this->get_value(3);
        }   
    }
    private function extract_total() {
        if(!isset($this->_out["tot_no_files"]) && $this->get_value(2)=="Total"){
            $this->_out["tot_no_files"] = preg_replace("/[^0-9]/", "", $this->get_value(5));           
        }   
    }
     private function extract_added() {
        if(!isset($this->_out["add_file"]) && $this->get_value(2)=="Added"){
            $this->_out["add_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));           
        }   
    }
     private function extract_changed() {
        if(!isset($this->_out["cha_file"]) && $this->get_value(2)=="Changed"){
            $this->_out["cha_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));           
        }   
    }
     private function extract_removed() {
        if(!isset($this->_out["rem_file"]) && $this->get_value(2)=="Removed"){
            $this->_out["rem_file"] = preg_replace("/[^0-9]/", "", $this->get_value(3));           
        }   
    }
    
 
    /**
     * 
     * @param type $line
     */
    public function get_data($path,$id) {
        $log_handle = fopen($path, 'r');   
        $this->_out = [];
        while (!feof($log_handle)) {
            $line = fgets($log_handle);
            $this->_exploded_arr = explode(" ", $line);
            $this->extract_date_time();
            $this->extract_total();
            $this->extract_changed();
            $this->extract_added();
            $this->extract_removed();
            if(count($this->_out) > 5){
                break;
            }
            //echo "couut = " . count($this->_out) . " <br/>";
            //var_dump($this->_exploded_arr);
        }
        fclose($log_handle);
        // return 
        if(count($this->_out) > 5){
            LogAddHelper::insert_aidelog($this->_out, $id);
        }
       // var_dump($this->_out);
        //return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($path,$id) {
        $obj = new self();
        return $obj->get_data($path,$id);
    }
}
