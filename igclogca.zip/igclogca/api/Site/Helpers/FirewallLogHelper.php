<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class FirewallLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
   private function extract_param($index) {
       $i=0;
        foreach ($this->_exploded_arr as $text) {
            if (strtolower(trim($text))== $index) {
                return $this->_exploded_arr[$i+1];
            }
            $i++;
        }
    }
    
     private function get_status() {       
        $index = 17;
        for($i=7;$i<count($this->_exploded_arr);$i++){
            $text = $this->_exploded_arr[$i];                  
            if (strpos(strtolower($text), "failed:") !== false) {
                $index = $i;
                break;
            }          
        }
       $msg_arr = array_slice($this->_exploded_arr, $index);
       return implode(" ", $msg_arr);   
    }

    private function common_data() {
        $this->_out["cdate"] = $this->get_value(0);
        $this->_out["ctime"] = $this->get_value(1);
        $this->_out["type"] = substr($this->get_value(2), 0, -1);
        $this->_out["cmd_status"] = substr($this->get_value(3), 0, -1);
        $this->_out["cmd"] = $this->get_value(4);
        $this->_out["f1"] = str_replace("-","",$this->get_value(5));
        $this->_out["f2"] = str_replace("-","",$this->get_value(6));
        $this->_out["table"] = str_replace("-","",$this->get_value(7));
        $this->_out["filter"] = str_replace("-","",$this->get_value(8));
        
        $this->_out["chain_cmd"] = str_replace("-","",$this->get_value(8));
        $this->_out["chain_type"] = str_replace("-","",$this->get_value(8));
        
        
        $this->_out["src_ip"] = $this->extract_param("--source");
        $this->_out["dest_ip"] = $this->extract_param("--destination");
        $this->_out["proto"] = $this->extract_param("--protocol");
        if(strlen($this->_out["proto"]) < 1){
             $this->_out["proto"] = $this->extract_param("--p");
        }
        $this->_out["d_port_no"] = $this->extract_param("--to-ports");
         if(strlen($this->_out["d_port_no"] ) < 1){
             $this->_out["d_port_no"]  = $this->extract_param("--destination-port");
        }
        $this->_out["out_if_name"] = $this->extract_param("--out-interface");
        if(strlen($this->_out["out_if_name"]) > 1){
            $this->_out["out_if"]  = "out-interface";
        }
         $this->_out["in_if_name"] = $this->extract_param("--in-interface");
        if(strlen($this->_out["in_if_name"]) > 1){
            $this->_out["in_if"]  = "in-interface";
        }
        $this->_out["ctstate"] = $this->extract_param("--ctstate");
        // conntrack
        $this->_out["conntrack"] = $this->extract_param("--match");
        //
        $this->_out["status"] = $this->get_status();
        /*
        $this->_out["dest_ip"] = str_replace("-","",$this->get_value(8));
        $this->_out["proto"] = str_replace("-","",$this->get_value(8));
        $this->_out["masq"] = str_replace("-","",$this->get_value(8));
        $this->_out["s_port_no"] = str_replace("-","",$this->get_value(8));
        $this->_out["d_port_no"] = str_replace("-","",$this->get_value(8));
        $this->_out["in_if"] = str_replace("-","",$this->get_value(8));
        $this->_out["in_if_name"] = str_replace("-","",$this->get_value(8));
        $this->_out["out_if"] = str_replace("-","",$this->get_value(8));
        $this->_out["out_if_name"] = str_replace("-","",$this->get_value(8));
        $this->_out["conntrack"] = str_replace("-","",$this->get_value(8));
        $this->_out["ctstate"] = str_replace("-","",$this->get_value(8));
        $this->_out["status"] = str_replace("-","",$this->get_value(8));
        */
        $this->_out["server_name"] = "";
    }

   
    private function check_invalid_command() {
        $command_status = $this->get_value(3);
        return $command_status == "INVALID_RULE:" ? true : false;
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
      //  var_dump($this->_exploded_arr);
        //
        $this->_out = [];
        //
        if (strlen($line) > 10 && !$this->check_invalid_command()) {
            //
            $this->common_data();
          //  var_dump($this->_out);
        }
        //
        // $this->get_paratmers_with_type();
        // var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  SYSCALL: Records a system call made by a process.
CRED_ACQ: Records the acquisition of a user credential.
CRED_DISP: Records the disposal of a user credential.
USER_START: Records the start of a user session.
USER_END: Records the end of a user session.
USER_LOGIN: Records a user login attempt.
USER_LOGOUT: Records a user logout event.
USER_AUTH: Records a user authentication event.
USER_ACCT: Records user account changes (e.g., password changes).
CONFIG_CHANGE: Records system configuration changes.
SYSTEM_RUNLEVEL: Records changes to the system runlevel (e.g., startup, shutdown).
SECCOMP: Records the use of the seccomp facility.
NETFILTER_CFG: Records changes to the netfilter configuration.
MAC_POLICY_LOAD: Records the loading of a MAC policy.
MAC_STATUS: Records the status of the MAC system.
ANOM_ABEND: Records an abnormal program termination.
ANOM_PROMISCUOUS: Records a change in network interface promiscuous mode.
ANOM_LOGIN_FAILURES: Records repeated failed login attempts.
 
 */

