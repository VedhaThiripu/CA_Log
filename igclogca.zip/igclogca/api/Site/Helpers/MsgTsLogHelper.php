<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class MsgTsLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $month = $this->get_value(0);
        $month_number = date("n", strtotime($month));
        $day = $this->get_value(2);
        $time = $this->get_value(3);
        $year = date("Y");
        return [$year . "-" . $month_number . "-" . $day, $time];
    }
    
     private function common_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->_out["type"] = substr($this->get_value(5), 0, -1);
        $this->_out["server_name"] = $this->get_value(4); 
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["remarks"] = implode(" ", $msg_arr); 
    }
  
    
    
    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = array_values(array_filter(explode(" ", $line)));
        array_splice($this->_exploded_arr, 1, 0, array(' '));
      //  var_dump($this->_exploded_arr);
        //
        $this->_out = [];
        //
        $this->common_data();     
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  SYSCALL: Records a system call made by a process.
CRED_ACQ: Records the acquisition of a user credential.
CRED_DISP: Records the disposal of a user credential.
USER_START: Records the start of a user session.
USER_END: Records the end of a user session.
USER_LOGIN: Records a user login attempt.
USER_LOGOUT: Records a user logout event.
USER_AUTH: Records a user authentication event.
USER_ACCT: Records user account changes (e.g., password changes).
CONFIG_CHANGE: Records system configuration changes.
SYSTEM_RUNLEVEL: Records changes to the system runlevel (e.g., startup, shutdown).
SECCOMP: Records the use of the seccomp facility.
NETFILTER_CFG: Records changes to the netfilter configuration.
MAC_POLICY_LOAD: Records the loading of a MAC policy.
MAC_STATUS: Records the status of the MAC system.
ANOM_ABEND: Records an abnormal program termination.
ANOM_PROMISCUOUS: Records a change in network interface promiscuous mode.
ANOM_LOGIN_FAILURES: Records repeated failed login attempts.
 
 */

