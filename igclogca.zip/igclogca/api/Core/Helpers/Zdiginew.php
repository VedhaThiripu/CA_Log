<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of zdiginew
 *
 * @author SUBBA RAJU
 */
class Zdiginew {

    private $_src;
    private $_dest;
    private $_schema;
    private $_schema_arr;
    private $_data;
    private $_id;
    private $_settings;
    private $_sig_count = 0;

    static public function getSettings($reason, $location = null) {
        $settings = [
            "reason" => $reason,
            "location" => $location === null ? "Kalpakkam" : $location
        ];
        return $settings;
    }

    //put your code here
    static public function get_data($src, $dest, $schema, $data, $settings = []) {
        $obj            = new self();
        $obj->_src      = $src;
        $obj->_dest     = $dest;
        $obj->_schema   = $schema;
        $obj->_data     = $data;
        $obj->_id       = 0;
        $obj->_settings = $settings;
        return $obj->ret_data();
    }

    private function ret_data() {
        // check source file to sign 
        $this->check_source_file();
        // 
        $this->check_load_schema();
        // get static data
        $db              = $this->get_static_data();
        //
        $db->json_fileds = $this->process_schema();
        // no of signs
        $db->no_of_signs = "" . $this->_sig_count;
        //
        return $db;
    }

    private function check_source_file() {
        if (!file_exists(DATA . $this->_src) && is_file(DATA . $this->_src)) {
            trigger_error("Source File Is Not Available. Please contact the Administrator", E_USER_ERROR);
        }
    }

    private function check_load_schema() {
        if (is_array($this->_schema)) {
            // this is added to send the details directly with out schema
            $this->_schema_arr = $this->_schema;
        } else {
            $dir    = "Site/schema/digi/";
            $schema = $dir . $this->_schema . ".json";
            //$schema = 
            if (!file_exists($schema)) {
                trigger_error("Schema File ( $schema) Not Avalable Please contact the Administrator", E_USER_ERROR);
            }
            $json_str          = file_get_contents($schema);
            $this->_schema_arr = json_decode($json_str, true);
        }
    }

    private function get_source_file_url() {
        return FILE_SERVICE_URL . General::encode($this->_src);
    }

    private function get_redirect_url() {        // 
        return FILE_UPLOAD_URL;
    }

    private function get_static_data() {
        //
        $db                  = new \stdClass();
        // inco
        $db->icno            = "10096"; //$GLOBALS["ICNO"];	
        //
        $db->unitoff         = "IGCAR";
        //
        $db->file_name       = base64_encode(DATA . $this->_dest);
        //
        $db->unique_name     = "0" . $this->_id;
        //
        $db->sigtype         = "json";
        //
        $db->source_file_url = $this->get_source_file_url();
        //
        $db->dest_url        = $this->get_redirect_url();
        //
        $db->browser_signing = true;
        //
        $db->application_url = FULL_SITE_API_URL . DS;
        //
        $db->sign_server     = FULL_SITE_API_URL . DS . "digisign.php?action=storejson";
        //
        $db->sign_server_new = "http://" . DIGI_SIGN_SERVER . "/iservernew";
        //
        $db->location        = isset($this->_settings["location"]) ? $this->_settings["location"] : "";
        //
        $db->reason          = isset($this->_settings["reason"]) ? $this->_settings["reason"] : "";
        //
        $db->recpos          = "#124#125#126";
        //
        $db->rect_name       = "emp_sig";
        //
        $db->json_urls       = [];
        //
        return $db;
    }

    private function process_schema() {
        $count = 0;
        $out   = [];
        //var_dump($this->_schema_arr);
        foreach ($this->_schema_arr as $signame => $fields) {
            //var_dump($fields);
            $sig_out   = $this->get_fileds($fields);
            $sig_out[] = $this->get_single_object($signame, "sig", "kms");
            $out[]     = $sig_out;
            $count++;
        }
        $this->_sig_count = $count;
        return $out;
    }

    private function get_fileds($fileds) {
        $out = [];
        foreach ($fileds as $field => $filed_marked) {
            $value = $this->get_field_data($filed_marked);
            $out[] = $this->get_single_object($field, "text", $value);
        }
        // var_dump($out);
        return $out;
    }

    private function get_field_data($field) {
        return isset($this->_data[$field]) ? $this->_data[$field] : "";
    }

    private function get_single_object($name, $type, $value) {
        $db        = new \stdClass();
        $db->type  = $type;
        $db->name  = $name;
        $db->value = base64_encode($value);
        return $db;
    }

}
