<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Session
 *
 * @author kms
 */
class Session {
    //put your code here
    
    public static function check(){
        //echo 
        return session_id()!=null ? true : false;
    }
    
    /**
     * 
     */
    public static function start(){
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    /**
     * 
     */
     public static function stop(){
        if(session_id()){
            session_destroy();
        }
    }
    /**
     * 
     * @param type $index
     * @param type $value
     */
    public static function set($index,$value){
       if(session_id()){
           $_SESSION[$index] = $value;
       }
    }
    /**
     * 
     * @param type $index
     * @param type $value
     */
     public static function get($index){
       if(session_id()){
           return isset($_SESSION[$index]) ? $_SESSION[$index] : null;
       }
       return null;
    }
    
    
    public static function get_instance(){
        if(!isset(self::$_instance)){
           self::$_instance = new Session();
        }
        return self::$_instance;
    }
    
}
