<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Model
 *
 * @author kms
 */
class Model extends Database{
    
    // tbale columns default 
    private $_tab_columns =[]; 
    // table name
    private $_tab_name= "";
    
    // database table sheme for inserting and validating 
    private $_schema = [];
    //
    private $_temp_data = [];
    private $_file_data = [];
    private $_files = [];
    //
    private $_errors =[];
    //
    private $_final_data = [];
    // where sql inarray format [ sql=>"" , parameters with key value pairs ] 
    private $_where_sql = [];
    // udpate entry not exists message
    private $_update_error_msg = "";
    //
    private $_sql_str = "";
    // select columns in the form or arary;
    private $_select_col= [];
    //    
    private $_from_str = "";
    private $_group_by = "";
    private $_order_by = "";
    private $_single = false;
    
    // unique column check
    private $_unique_check = false;
    private $_delete_check = null;
    
    //put your code here
    function __construct($schema_file=NULL) {
        parent::__construct();
        
        // check shema file name is mentioned 
        if($schema_file!=NULL){
            $this->process_schema($schema_file);
        }
    }
    // process the scema file to get the details
    private function process_schema($schema_file){
        $dir = "Site/schema/";
        $schema_file_new = str_replace("__", "/", $schema_file);
        $file = $dir .$schema_file_new .".json";
        if(!file_exists($file)) trigger_error("Schema File Does Not Exists : $schema_file ",E_USER_ERROR);
        $json_str = file_get_contents($file);
        $json_obj = json_decode($json_str,true); 
       // var_dump($json_obj);
        // check for table 
        if(!isset($json_obj["table"])) trigger_error("Schema File Does Not Contain table name : $schema_file ",E_USER_ERROR);
        $this->UpdateTabName($json_obj["table"]);
        
        // get columns & schema and update 
        if(!isset($json_obj["schema"])) trigger_error("Schema File Does Not Contain schema: $schema_file ",E_USER_ERROR);
        $this->UpdateColumns(array_keys($json_obj["schema"]));
        $this->UpdateSchema($json_obj["schema"]);
        
        // update unique check columns if available 
        if(isset($json_obj["unique"])){
            $this->UpdateUnique($json_obj["unique"]);
        }
        // delete check
         if(isset($json_obj["deletecheck"])){
            $this->UpdateDelete($json_obj["deletecheck"]);
        }
        
    }

    


    /**
    * 
    * @param type $schema
    * @return $this
    */
    public function UpdateSchema($schema){
        $this->_schema = $schema;
        return $this;
    }
    /**
     * 
     * @param type $columns
     * @return $this
     */
    public function UpdateColumns($columns){
        $this->_tab_columns = $columns;
        return $this;
    }
    public function Columns($columns){
        $this->_tab_columns = $columns;
        return $this;
    }
   /**
    * 
    * @param type $table
    * @return $this
    */
    public function UpdateTabName($table){
        $this->_tab_name = $table;
        return $this;
    }
    /**
     * 
     * @param type $sql
     * @return $this
     */
    public function WhereSql($sql){
        $this->_where_sql = $sql;
        return $this;
    }
    
    /**
     * 
     * @param type $msg
     * @return $this
     */
    public function UpdateErrorMsg($msg){
        $this->_update_error_msg = $msg;
        return $this;
    }
    /**
     *  update the sql sterin in parameterized format like after where query for delete or full query fro fetch 
     *  For DELETE : ID=:ID  
     * 
     * @param type $sql
     * @return $this
     */
    public function UpdateSql($sql){
        $this->_sql_str= $sql;
        return $this;
    }
    public function Where($sql){
         $this->_sql_str= $sql;
        return $this;
    }
    /**
     * 
     * @param type $check
     * @return $this
     */
     public function UpdateUnique($check){
        $this->_unique_check= $check;
        return $this;
    }
     public function UpdateDelete($check){
        $this->_delete_check= $check;
        return $this;
    }
    /**
     *  has to pass array of columns
     * 
     * @param array $select_cols 
     */
    public function Select($select_cols){
        $select_cols_updated = is_string($select_cols) ? [$select_cols] : $select_cols;
        $this->_select_col = $select_cols_updated;
        return $this;
    }
    /**
     *  from string of the data
     * 
     * @param type $from
     */
    public function From($from){
        $this->_from_str = $from;
        return $this;
    }
    
    /**
     *  from string of the data
     * 
     * @param type $from
     */
    public function GroupBy($groupBy){
        $this->_group_by = $groupBy;
        return $this;
    }
    
    /**
     *  from string of the data
     * 
     * @param type $from
     */
    public function OrderBy($orderBy){
        $this->_order_by = $orderBy;
        return $this;
    }
    /**
     * 
     */
    public function Multiple(){
        $this->_single = false;
        return $this;
    }
    // one 
    public function One(){
        $this->_single = true;
        return $this;
    }
    
    /**
     * 
     * @param type $sql
     * @return $this
     */
     public function Sql($sql){
        $this->_sql_str= $sql;
        return $this;
    }
    
    
    public function fetchAll(){
        return $this->fetchAllData($this->_tab_name);
    }
    /**
     * 
     * @param type $id
     * @return type
     */
    public function fetchOne($id){
        $this->_select_col = ["*"];
        $this->_sql_str = "ID=:ID";
        $this->_from_str = $this->_tab_name;
        $data = new \stdClass();
        $data->ID = $id;
        $this->_single = true;
        return $this->getDataFull($data);
    }
    /**
     * 
     * @param type $datain
     * @return type
     */
    public function getDataFull($datain){
        // select query
        $select = !empty($this->_select_col) ? implode(",",$this->_select_col) : " * "; 
        // check from string if not add the table name  as from string
        $this->_from_str = strlen($this->_from_str) > 1 ? $this->_from_str : $this->_tab_name;
        // print other values
        $sql_str = sprintf("SELECT %s FROM %s ",$select,$this->_from_str);
        //echo $sql_str;
        if(strlen($this->_sql_str) > 1 ){
            $sql_str .=" WHERE " . $this->_sql_str;
        } 
        if(strlen($this->_group_by) > 1 ){
            $sql_str .=" GROUP BY " . $this->_group_by;
        } 
        if(strlen($this->_order_by) > 1 ){
            $sql_str .=" ORDER BY " . $this->_order_by;
        }
       // echo "<br/>".$sql_str . " <br/><br />";
        //var_dump($datain);
       //echo "<br/><br/> SQL = " . $sql_str . " <br/><br/>";
        $data =  $this->getData($sql_str, $datain, $this->_single);
        return $data;
    }
    /**
     * 
     * @param type $data
     */
    public function validate($data){
         $this->_temp_data = $data;
         $this->validate_data($this->_tab_columns,true);
        if(!empty($this->_errors)){
           $msg = json_encode($this->_errors);
            trigger_error($msg,E_USER_WARNING);  
        }
    }
    /**
     * 
     * @param type $data
     * @return type
     */
     public function validate_retrun_errors($data){
         $this->_temp_data = $data;
         $this->validate_data($this->_tab_columns,true);
         return $this->_errors;
    }
    
    /**
     * 
     * @param type $data
     */
    public function insertwithdata($data,$file_data=NULL){
        // do validation 
        $this->_temp_data = $data;
        $this->_file_data = $file_data;
        // do insertiong 
        $this->validate_data($this->_tab_columns,true);
        //
       // var_dump($this->_errors);
        if(empty($this->_errors)){
           // no process the data  along with schema 
          $this->_final_data = $this->prepare_data($this->_tab_columns);        
           // now insert the data inside tbale and get id and return 
           $data_out = $this->InsertData($this->_tab_name,$this->_final_data);
           // if file are avilable handle and update it 
           if(!empty($this->_files)) { $this->process_files($data_out); }
           
           return $data_out;
        }else{
           // var_dump($this->_errors);
            $msg = json_encode($this->_errors);
            \CustomErrorHandler::triger_error($msg);
           // trigger_error($msg,E_USER_WARNING);
          // var_dump($this->_errors);
           return null;
        }
        
    }
    
    private function process_files($data_out) {
        //
        $id = isset($data_out["id"]) ? $data_out["id"] : 0;
        //
        $fileObj = new SmartFile($this->_tab_name,$id);
        // var_dump($this->_files);
        $fileObj->processMulti($this->_files);
    }
    
    
    /**
     * 
     * @param array $data
     * @param type $id
     */
    public function update($data,$id,$files=[],$column=""){
        $this->_where_sql["sql"] = "ID=:ID";
        if(strlen($column) > 1){
            $this->_where_sql["sql"] = "$column=:ID";
        }
        $this->_where_sql["ID"]=$id;       
       // var_dump($data);
        return $this->updatewithdata($data,$files,$id);
    }
    
    /**
     * 
     * @param type $data
     * @return type
     */
    public function updatewithdata($data,$file_data=NULL,$id=0){
        // do validation 
        $this->_temp_data = $data;
        $this->_file_data = $file_data;
        // get the update columns from the given data
        $this->_tab_columns = empty($this->_tab_columns) ? array_keys($data) : $this->_tab_columns; 
        //var_dump($this->_tab_columns);
        // do insertiong 
        $this->validate_data($this->_tab_columns,false);
       // var_dump($data)
        //
        if(empty($this->_errors)){
           // no process the data  along with schema 
           $this->_final_data = $this->prepare_data($this->_tab_columns); 
          // echo "final data = <br/>";  
          // var_dump($this->_final_data);
          // echo "where = <br/>";  
          // var_dump($this->_where_sql);
           // now insert the data inside tbale and get id and return 
           $this->UpdateData($this->_tab_name,$this->_final_data,$this->_where_sql); 
           //
          // var_dump($this->_files);
           
           if(!empty($this->_files)) { $this->process_files(["id"=>$id]); }
           //
           $out_data = $this->_final_data;
           $out_data["id"]=$id;
           return $out_data;
           //
          // return $count;
        }else{
            $msg = json_encode($this->_errors);
            //
            trigger_error($msg,E_USER_WARNING);
          // var_dump($this->_errors);
           return null;
        }
        
    }
    /**
     * 
     * 
     * @param type $data
     */
    public function deltewithdata($data){
          $count = $this->DeleteData($this->_tab_name,$this->_sql_str,$data);
          if($count==NULL || $count < 1){
              // trigger_error($this->_update_error_msg,E_USER_ERROR);
          }
    }
    /**
     * 
     * @param type $id
     */
    public function deltewithid($id){
          $sql = "ID=:ID";
          $data = new \stdClass();
          $data->ID = $id;
          // if delete check is mentioned in model file use that
          $del_check = $this->_delete_check;
          //var_dump($del_check);
          if($del_check!=null){
              // process the delete check and check for errors
              $this->delete_check($del_check, $id);
          }  
         // var_dump($data);
          $count = $this->DeleteData($this->_tab_name,$sql,$data);
         // echo "count = " . $count;
          if($count==NULL || $count < 1){
              trigger_error($this->_update_error_msg,E_USER_ERROR);
          }
    }
    
            
    /**
     * 
     * @param type $columns
     * @return type
     */
    private function prepare_data($columns) {
        $smartInsert = new SmartInsert($this->_temp_data,$this->_schema,$columns, $this->_file_data );
        list($data,$this->_files) = $smartInsert->prepare_data();
       // echo "data = <br/>";        
       // var_dump($this->_files);
        return $data;
    }
    
    /**
     * 
     * @param type $columns
     */
    private function validate_data($columns,$insert){
        $validator = new SmartValidator($this->_temp_data,$this->_file_data);
        //var_dump($columns);
        foreach($columns as $col_name){
            $sobj = isset($this->_schema[$col_name]) ? $this->_schema[$col_name] : null;
            if($sobj!=NULL){               
                 $valid =  isset($sobj["validation"]) ? $sobj["validation"] : [];
                 // pre validation condition 
                 $pre_valid_cond = isset($sobj["cond"]) ? $sobj["cond"] : [];
                 // check 
                 $validation_check = !empty($pre_valid_cond)  ? $validator->pre_validate_function($col_name, $pre_valid_cond) : true;
                 //
                 //echo "<br/><br/>" . $col_name . " === check = " . $validation_check . "";
                // $this->do_validation_field($col_name, $valid);
                 if($validation_check===true){
                    $validator->validate_single_field($col_name, $valid);
                 }
            }
        }
        // get errors and update 
        $this->_errors = $validator->getErrors();
        //var_dump($this->_errors);
        // if unique is set validation unique colums also 
        if(empty($this->_errors) && $insert==true && $this->_unique_check !=false){
           // echo "entering in uniqu";
            $this->check_unique();
        }        
        
    }
    /**
     * 
     */
    public function check_unique(){
        // preparation of sql to check unique ness 
        $where = [];
        $data_in = [];
        foreach($this->_unique_check["check"] as $column){
            $data_in[$column] = $this->get_value_from_data($column);
            $where[] =  "$column=:$column";
        }
       $sql_str = sprintf("SELECT ID FROM %s WHERE %s",$this->_tab_name,implode(" AND ",$where));
      // echo $sql_str;
      // var_dump($data_in);
       $data = $this->getData($sql_str, $data_in, true);
      // var_dump($data);
       if(isset($data->ID)){
            $this->_errors[] = $this->_unique_check["msg"];
       }
    }
    
    public function delete_check($del_check,$id){      
        $msg = isset($del_check["msg"]) ? $del_check["msg"] : "Delete Error";
       // var_dump($del_check);
        foreach($del_check["check"] as $arr){
            $tablename = isset($arr[0]) ? trim($arr[0]) : null;
            $col_name = isset($arr[1]) ? trim($arr[1]) : null;
            $res = $this->single_delete_check($tablename, $col_name, $id);
            if($res === true){
               trigger_error($msg,E_USER_ERROR);
            }         
        }    
    }
    
    private function single_delete_check($tablename,$col_name,$id){
        $sql_str = sprintf("SELECT ID FROM %s WHERE %s=%s",$tablename,$col_name,$id);
        //echo "sql = " . $sql_str;
        $data = $this->getData($sql_str, [], true);
        //var_dump($data);
        return isset($data->ID) ? true : false;
    }
    
    
     private function get_value_from_data($column_name){
        if(isset($this->_temp_data[$column_name])){
            $value = $this->_temp_data[$column_name];
            if(!is_array($value)){
                return trim($value);
            }else{
                return implode(",",array_filter($value));
            }
        }else{
            return null;
        }
      //  return isset($this->_temp_data[$column_name]) && !is_array($this->_temp_data[$column_name]) ? trim($this->_temp_data[$column_name]) : null;
    }
    
   
   
    
}
