<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of Zpdf
 *
 * @author SUBBA RAJU
 */
class Zpdf {
    
    static public function createDirectories($dirpath){         
          $str = explode("/", $dirpath);
         // var_dump($str);
          $dir = '';
          foreach($str as $dpath){
              $ext = self::getExt($dpath);
            //  echo "ext".$dpath." - ".$ext."<br/>";
              if(strlen($ext) < 1){
              $dir .= "/". $dpath ;
               if(!file_exists($dir)){ mkdir($dir);}
              }
          }
     }
    
    static public function getExt($path){
         $ext = pathinfo($path, PATHINFO_EXTENSION);
         if(str_getcsv(trim($ext)) > 1){
             return $ext;
         }else{
             return NULL;             
         }
     }
    //put your code here
    static public function genPdf($html,$location,$settings=[]){
         $location_full = DATA . $location;
         self::createDirectories($location_full);
         ini_set('memory_limit','2048M');
        
         $format = isset($settings["pagesize"]) ? $settings["pagesize"] : "A4";
         $font_size = isset($settings["fontsize"]) ? $settings["fontsize"] : 10;
         $unicode = isset($settings["unicode"]) && intval($settings["unicode"])==1 ? true : false;
         include_once("../../common/MPDF/mpdf.php");
         $mpdf = new \mPDF($mode='utf-8',$format,$font_size);
         $mpdf->simpleTables = true;
         $mpdf->setFooter('Page:{PAGENO} / {nb}');
         if($unicode===true){
             $html = utf8_encode($html);
         }
         $mpdf->WriteHTML($html);
         $mpdf->Output($location_full,'F'); 
    }
}
