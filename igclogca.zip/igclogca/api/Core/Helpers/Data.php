<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Data
 * 
 *  class helps to get the data from post with specified type 
 *
 * @author kms
 */
class Data {
    //put your code here
    
    static public function post_data($name,$type){
        switch($type){
            case "INTEGER" : return self::post_int_data($name); 
            case "FLOAT" : return self::post_float_data($name);
            case "EMAIL" : return self::post_email_data($name);
            case "ARRAY" : return self::post_array_data($name);
            case "ARRAY_TO_STRING" : return self::post_array_to_string_data($name);
            case "STRING" : 
            default : return self::post_string_data($name);
        }
    }
    /**
     * 
     * @param type $name
     * @return type
     */
    static public function post_string_data($name){      
          return  isset($_POST[$name]) ? filter_var ( $_POST[$name], FILTER_SANITIZE_STRING) : null;
    }
    /**
     * 
     * @param type $name
     * @return type
     */
    static public function post_int_data($name){
        return  isset($_POST[$name]) ? filter_var ( $_POST[$name], FILTER_SANITIZE_NUMBER_INT) : null;
    }
   /**
    * 
    * @param type $name
    * @return type
    */
    static public function post_float_data($name){
        return  isset($_POST[$name]) ? filter_var ( $_POST[$name], FILTER_SANITIZE_NUMBER_FLOAT,FILTER_FLAG_ALLOW_FRACTION) : null;
    }
   /**
    * 
    * @param type $name
    * @return type
    */
    static public function post_email_data($name){
        return  isset($_POST[$name]) ? filter_var ( $_POST[$name], FILTER_SANITIZE_EMAIL) : null;
    }
    /**
     * 
     * @param type $name
     * @return type
     */
    static public function post_array_data($name){
        return  isset($_POST[$name]) && is_array($_POST[$name]) ? $_POST[$name] : []; 
    }
    
    static public function post_array_to_string_data($name){
       $arr = self::post_array_data($name);
       return !empty($arr) ? implode(", " , $arr) : "";
    }
    
    
}
            