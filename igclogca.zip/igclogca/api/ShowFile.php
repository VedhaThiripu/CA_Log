<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of ShowFile
 *
 * @author subbaraju
 */
error_reporting(E_ALL);

include "CorsEnable.php";
  
class showFile {
    //put your code here
     // file
       public $fileloc = '';
       // get the extenstion of file
       public $ext;
       // get the file name
       public $filename ='test';
       
       
       function __construct() {
           // get the file
           $floc = (isset($_GET["file"]) ? base64_decode($_GET["file"]) : NULL);
           // 
           if(strlen($floc)<2){
               exit("Invalid File");
           }
           // 
           $this->fileloc = DATA . $floc;
           // 
           if(strpos($floc, DATA) !== false){
              $this->fileloc = $floc;  
           }          
           //echo "fileloc = " .$this->fileloc;
           // get the file name
           $this->filename = basename($this->fileloc);           
           // get the extenstion
           $this->get_ext();
           // show the file
           $this->outFile();
       }
       
       /**
        * getting the extension
        */
       private function get_ext(){
           $this->ext = strtolower(pathinfo($this->fileloc, PATHINFO_EXTENSION));
       }
       
       /**
        * 
        */
       private function outFile(){
          if(file_exists($this->fileloc)){ 
            switch($this->ext){
              case 'pdf' : $this->showPdf();
                  break;
              case 'gif' : $this->showGif();
                  break;
              case 'aes' : $this->showEncryptedFile();
                  break;
              default: $this->download();
                  break;
            } 
          }else{
              echo "file not found " . $this->fileloc;
          }
           
       }
       
       // show encripted file
       public function showEncryptedFile(){
           require_once APPDIR.'core/helpers/zencr.php';
           $zencr = new zencr();
           //echo $this->fileloc;
           $atts = ["src"=>$this->fileloc];
           $zencr->decrypt_file($atts);
           $this->fileloc = substr($this->fileloc, 0, -4);
           $this->filename = basename($this->fileloc);
           //echo $this->fileloc;
           $this->showPdf();
           // remove the file after showing it
           $this->remove_file($this->fileloc);
          // echo "testing";
           exit();
       }
       
       private function remove_file($file_loc){
           if(file_exists($file_loc)){
               unlink($file_loc);
           }
       }
       
       private function showPdf(){
           header('Content-type: application/pdf');
	   header('Content-Disposition: inline; filename='.$this->filename.'');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($this->fileloc));
            @readfile($this->fileloc); 
       }
       
       private function showGif(){
            header('Content-type: image/gif');
	    header('Content-Disposition: inline; filename='.$this->filename.'');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($this->fileloc));
            @readfile($this->fileloc); 
       }
       
        private function download(){
            header('Content-type: application/octet-stream');
	    header('Content-Disposition: inline; filename='.$this->filename.'');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($this->fileloc));
            @readfile($this->fileloc); 
       }
       
}
new showFile();
