<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Database configuration settings
 * username , password ,  databasename ,  Host address
 */
// MYSQL host address: default is local host and if the database is on another server 
// use ip address or dns entry of the server
define("DB_HOST", "localhost");
// mysql user name 
define("DB_USER", "root");
// mysql password
define("DB_PASS", "");
// database name
define("DB_NAME", "igclogca");
// port
define("DB_PORT", 3306);

/**
 *  site settings 
 * 
 */
define("SITEDIR", "igclogca");
// data directory
define("DATA", "/var/www/html/canew/data/");

// Developement Settings 
define("FRAME_DEBUG", TRUE);
// basic core path 
define("CORE_CODE_PATH", "core");
//
define("SITE_CODE_PATH", "site");
// directory sepearatior
define("DS", "/");

// Totoal count
define("TOTAL_COUNT", 20000000);
// log files line read maximum count in cron job :zero indicates end of the log
define("TOTAL_CRON_COUNT", 200);

// site title and image
define("SITE_TITLE","SERVER LOG MANAGEMENT");
define("SITE_LOGO","igcar-logo.png");
define("SITE_FOOTER","Designed &  Developed by Computer Division, IGCAR");


// log types
$log_types_config = [
    "AUDIT" => "Audit Log",
    "MSG" => "Messages",
    "MSG_TS" => "Messages Timestamp",
    "CRON" => "Cron Log",
    "TIMESTAMP" => "Timestamp Log",
    "HARDSERVER" => "Hard Server Log",
    "SECURE" => "Secure Log",
    "FIREWALL" => "Firewall Log",
    "RASERVER" => "RA Server Log",
    "BOOT"=>"Boot Log",
    "OCSP"=>"Ocsp Log",
    "AIDE"=>"Aide Log"
];
/*
$log_types_config = [
    "AUDIT" => "Audit Log",
    "MSG" => "Messages",
    "CRON" => "Cron Log",
    "DNS" => "DNS Log",
];
 * 
 */
