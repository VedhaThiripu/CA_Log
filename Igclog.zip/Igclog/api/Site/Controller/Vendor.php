<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site\Controller;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;
use Core\Helpers\Data as Data;
use Core\Helpers\Session as Session;
use Core\Helpers\SmartGLobals as Globals;


/**
 * Description of Apibackend
 *
 * @author kms
 */
 class Vendor extends Controller{
	
	
	public function vendaddr($param){
		 $this->registerCurd("vendaddr", $param, $_POST,$_FILES);
    }
	public function vendbank($param){
		$this->registerCurd("vendbank",$param ,$_POST,$_FILES);
	}
	public function vendors($param){
		$this->registerCurd("vendors",$param,$_POST,$_FILES);
	}
	// TO GET THE VENDADDR  ID AS THE FIRSTPARAMETER
	public function get_vendaddr_id($param){
		$firstparam = isset($param["firstParam"]) ? $param["firstParam"] : "";
         $model = new Model("vendaddr");
         $data = $model->Select(["*"])
                 ->From("vendaddr ")
                 ->Where("pid='$firstparam' ")
                 ->getDataFull([]);
         $this->suceess_output($data);
    }
	
	// TO GET THE VENDBANKs for the given vendor id 
	public function get_vendbank_id($param){
		$firstparam = isset($param["firstParam"]) ? $param["firstParam"] : "";
         $model = new Model("vendbank");
         $data = $model->Select(["*"])
                 ->From("vendbank ")
                 ->Where("pid='$firstparam' ")
                 ->getDataFull([]);
         $this->suceess_output($data);
    }
	
	//TO GET THE ID AND PID FROM VENDBANK WHERE THE VEMAIL FROM THE VENDADDR WHERE THE STATUS AS FIRSTPARAMETER
   //SQL=SELECT t1.ID,t1.pid,t2.vemail FROM vendbank t1 INNER JOIN vendaddr t2 ON t2.ID = t1.pid WHERE t1.bstatus =2
	public function vendor_vendbank_get_status($param){
        $firstparam = isset($param["firstParam"]) ? $param["firstParam"] : "";
         $model = new Model("vendbank");
         $data = $model->Select(["t1.ID ","t1.pid","t2.vemail"])
                 ->From("vendbank t1 INNER JOIN vendaddr t2 ON t2.ID=t1.pid ")
                 ->Where("t1.bstatus='$firstparam' ")
                 ->getDataFull([]);
         $this->suceess_output($data);
    }
 }	 
 