<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Controller;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;
use Core\Helpers\Data as Data;

use Site\Helpers\LogAddHelper as LogHelper;
//
use Site\Helpers\TableHelpers as Table;
/**
 * Description of LogShow
 *
 * @author 91939
 */
class LogShow Extends Controller {
    //put your code here
    //
    private $_id = 0;
     //
    private $_table;
    //
    private $_cat;
    
    private $_search_type;
    //
    private $_sdate;
    //
    private $_edate;
    //
    private $_start;
    //
    private $_limit;
    //
    private $_with_type = false;
    //
    private $_type = "";
    /**
     * 
     */
    private function get_cat_and_table($cat="") {
        $this->_cat = $cat=="" ?  LogHelper::getSingleCat($this->_id) : $cat;
        switch($this->_cat){
            case "CRON" : $this->_table = Table::CRON; break;
            case "DNS" : $this->_table  = Table::DNS; break;
            case "AUDIT" : $this->_table  = Table::AUDIT; break;
            case "MSG" : $this->_table  = Table::MSG; break;
            default: 
                \CustomErrorHandler::triger_error("invalid cat");
                break;
        }
    }
    private function prepare_time_stamp_sql(){
        if(strlen($this->_sdate)>2 && strlen($this->_edate)>2){
            return " AND DATE(cdate) BETWEEN '$this->_sdate' AND '$this->_edate'";
        }
    }
    /**
     * 
     * @return type
     */
    private function prepare_limit_sql(){
       // echo "start =" . $this->_start ." end =" . $this->_limit;
        if($this->_start >= 0 && $this->_limit > 0){
            return " ORDER BY cdate desc,ctime desc LIMIT ".($this->_start-1).",".$this->_limit."";
        }
    }
    
    private function get_cat_with_type() {       
        switch($this->_cat){
            case "CRON" : return "job='$this->_type'";
            case "DNS" : return "qry_type='$this->_type'";
            case "AUDIT" :return "type='$this->_type'";
            case "MSG" : return "type='$this->_type'";
            default: 
                \CustomErrorHandler::triger_error("invalid cat");
                break;
        }
    }

    /**
     * 
     * @return type
     */
    private function prepare_sql($type=""){
        $sql = "";
        // prepare time stamp sql
        $sql .= $this->prepare_time_stamp_sql();
        //
        if($type=="DATE_TYPE"){
            $sql .= " AND " . $this->get_cat_with_type();
        }
        //
        return $sql;
    }
    
    
    /**
     * 
     * @param type $sql
     * @param type $data_in
     * @param type $select
     * @param type $count
     * @return type
     */
   private function get_all($sql,$data_in=[],$select=[],$count=false) {
        $model = new Model();
        if(count($select)>0){
            $model->Select($select);
        }
        $model->From($this->_table);
        $model->Where($sql);
        if($count===true){
            $model->Select(["COUNT(*) as totcount"]);
            $model->One();
        }
      //  $model->OrderBy(" cdate DESC");
        $data = $model->getDataFull($data_in);
        //var_dump($data);
        if($count===true){
            return isset($data->totcount) ? $data->totcount : 0;
        }
        return $data;
    }
    
     private function get_cat_group_count($sql) {       
        switch($this->_cat){
            case "CRON" : return $this->get_all($sql." GROUP BY job",[],["job as type","COUNT(*) as totcount"]);
            case "DNS" : return $this->get_all($sql." GROUP BY qry_type",[],["qry_type as type","COUNT(*) as totcount"]);
            case "AUDIT" :return $this->get_all($sql." GROUP BY type",[],["type","COUNT(*) as totcount"]);
            case "MSG" : return $this->get_all($sql." GROUP BY type",[],["type","COUNT(*) as totcount"]);
            default: 
                \CustomErrorHandler::triger_error("invalid cat");
                break;
        }
    }
    /**
     * 
     */
    private function return_date_search_data($type=""){
        
        $out = new \stdClass();
        // full data with limit flags
        $sql =  $this->_with_type === false ? "infotable_id=$this->_id" : " ID > 0 ";
        //
        $sql .= $this->prepare_sql($type);
        // get group data with sql
        $out->group_ccount = $this->get_cat_group_count($sql);
        // toal count
        $out->total_count = $this->get_all($sql, [], [], true);
        
        if($type!=="GROUP_COUNT"){
        // 
        $sql .= $this->prepare_limit_sql();
        //
        $out->data =  $this->get_all($sql);
        }
        //
        return $out;
    }
    /**
     * 
     * @return \stdClass
     */
    private function search_data(){
        $out = new \stdClass();
       //echo "search_type = " . $this->_search_type ; 
        switch($this->_search_type){
            case "DATE": return $this->return_date_search_data();
            case "DATE_GROUP": return $this->return_date_search_data("GROUP_COUNT");
            case "DATE_TYPE": return $this->return_date_search_data("DATE_TYPE");
            default :
                break;
        }
        return $out;
    }
    /**
     * 
     */
    private function process_input_data($param) {
        $this->checkRequestType("POST");
        // get id
        $this->_id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        $this->_search_type = Data::post_data("search_type", "STRING");
        // now prepare sql and data in
        $this->_sdate = Data::post_data("sdate", "DATE");
        $this->_edate = Data::post_data("edate", "DATE");
        // Limit flags 
        $this->_start = Data::post_data("start", "INTEGER");
        $this->_limit = Data::post_data("limit", "INTEGER");
        // type
        $this->_type = Data::post_data("type", "STRING");
    }
    
    /**
     * 
     * @param type $param
     * @return type
     */
    public function getData($param){
        $this->process_input_data($param);
        // get cat and update the table
        $this->get_cat_and_table();
        //
        $data = $this->search_data();
        // output 
        $this->succeess_output($data);
    }
    
     public function getDataWithType($param){
        $this->process_input_data($param);
        //
        $cat = Data::post_data("log_type", "STRING");
        //
        $this->_with_type = true;
        // get cat and update the table
        $this->get_cat_and_table($cat);
        // 
        $data = $this->search_data();
         // output 
        $this->succeess_output($data);
    }
    
    
    
    public function getCron(){
        $this->checkRequestType();
        $model = new Model();
        $data = $model->From("cron_table")
                ->Select(["*","(CASE WHEN status=1 THEN 'Success' WHEN status=2 THEN 'Failed' ELSE 'Initiated' END) as status_desc"])
                ->getDataFull([]);
        $this->succeess_output($data);
    }
}
