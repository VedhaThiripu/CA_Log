<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class DnsLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $month = $this->get_value(0);
        $month_number = date("n", strtotime($month));
        $day = $this->get_value(1);
        $time = $this->get_value(2);
        $year = date("Y");
        return [$year . "-" . $month_number . "-" . $day ,$time];
    }

    /**
     * 
     * @return type
     */
    private function get_ip_and_port($index = 0) {
        $index_new = $index == 0 ? 9 : $index;
        $client = $this->get_value($index_new);
        $exploded = explode("#", $client);
        $client_ip = isset($exploded[0]) ? $exploded[0] : "";
        $client_port = isset($exploded[1]) ? $exploded[1] : "";
        return [$client_ip, $client_port];
    }

    /**
     * 
     */
    private function common_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->_out["qry_type"] = substr($this->get_value(5), 0, -1);
        $this->_out["server_name"] = $this->get_value(3);
        $this->_out["daemon"] = $this->get_value(4);
        $this->_out["qry_lvl"] = $this->get_value(6);
    }

    /**
     * 
     */
    private function get_query_parameters() {
        list($this->_out["client_ip"], $this->_out["client_port"]) = $this->get_ip_and_port();
        $this->_out["client_name"] = $this->get_value(8);
        $this->_out["domain_name"] = $this->get_value(12);
        $this->_out["record_type"] = $this->get_value(14);
        $this->_out["domain_ip"] = str_replace(")", "", str_replace("(", "", $this->get_value(16)));
    }

    private function get_query_error_parameters() {
        list($this->_out["client_ip"], $this->_out["client_port"]) = $this->get_ip_and_port();
        $this->_out["client_name"] = $this->get_value(8);
        $this->_out["domain_name"] = $this->get_value(12);
        $explode = explode("/", $this->get_value(15));
        $this->_out["record_type"] = isset($explode[2]) ? $explode[2] : "";
        $this->_out["remarks"] = $this->get_value(17);
    }

    private function get_rpz_parameters() {
        list($this->_out["client_ip"], $this->_out["client_port"]) = $this->get_ip_and_port();
        $this->_out["client_name"] = $this->get_value(8);
        $this->_out["domain_name"] = str_replace("(", "", str_replace(")", "", $this->get_value(10)));
        $explode = explode("/", $this->get_value(15));
        $this->_out["record_type"] = isset($explode[1]) ? $explode[1] : "";
        $msg_arr = array_slice($this->_exploded_arr, 11);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_dnsec_parameters() {
        $explode = explode("/", $this->get_value(8));
        $this->_out["domain_name"] = isset($explode[0]) ? $explode[0] : "";
        $this->_out["record_type"] = isset($explode[0]) ? str_replace(":", "", $explode[0]) : "";
        $msg_arr = array_slice($this->_exploded_arr, 9);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_resolver_parameters() {
        $msg_arr = array_slice($this->_exploded_arr, 7);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_general_parameters() {
        $explode = explode("/", $this->get_value(8));
        $this->_out["domain_name"] = isset($explode[0]) ? $explode[0] : "";
        $this->_out["record_type"] = isset($explode[0]) ? str_replace(":", "", $explode[0]) : "";
        $this->_out["domain_ip"] = str_replace(")", "", str_replace("(", "", $this->get_value(9)));
        $msg_arr = array_slice($this->_exploded_arr, 10);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_db_parameters() {
        $msg_arr = array_slice($this->_exploded_arr, 7);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    /**
     * 
     */
    private function get_cname_parameters() {
        $this->_out["domain_name"] = $this->get_value(9);
        $explode = explode("/", $this->get_value(17));
        $this->_out["record_type"] = isset($explode[1]) ? str_replace(":", "", $explode[1]) : "";
        $msg_arr = array_slice($this->_exploded_arr, 7);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_update_parameters() {
        list($this->_out["client_ip"], $this->_out["clinet_port"]) = $this->get_ip_and_port();
        $msg_arr = array_slice($this->_exploded_arr, 10);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_dispatch_parameters() {
        list($this->_out["client_ip"], $this->_out["clinet_port"]) = $this->get_ip_and_port(16);
        $msg_arr = array_slice($this->_exploded_arr, 9);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_security_parameters() {
        list($this->_out["client_ip"], $this->_out["clinet_port"]) = $this->get_ip_and_port();
        $this->_out["domain_name"] = str_replace("(", "", str_replace(")", "", $this->get_value(10)));
        $explode = explode("/", $this->get_value(13));
        $this->_out["record_type"] = isset($explode[1]) ? $explode[1] : "";
        $msg_arr = array_slice($this->_exploded_arr, 11);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_edns_parameters() {
        $explode = explode("/", $this->get_value(9));
        $this->_out["domain_name"] = isset($explode[0]) ? str_replace("'", "", $explode[0]) : "";
        $this->_out["record_type"] = isset($explode[1]) ? str_replace("'", "", $explode[1]) : "";
        $msg_arr = array_slice($this->_exploded_arr, 8);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    /**
     * 
     */
    private function get_paratmers_with_type() {
        switch ($this->_out["qry_type"]) {
            case "queries": $this->get_query_parameters();
                break;
            case "dnssec": $this->get_dnsec_parameters();
                break;
            case "resolver" : $this->get_resolver_parameters();
                break;
            case "general" : $this->get_general_parameters();
                break;
            case "query-errors" : $this->get_query_error_parameters();
                break;
            case "rpz" : $this->get_rpz_parameters();
                break;
            case "database" : $this->get_db_parameters();
                break;
            case "cname" : $this->get_cname_parameters();
                break;
            case "update-security" : $this->get_update_parameters();
                break;
            case "dispatch" : $this->get_dispatch_parameters();
                break;
            case "security" : $this->get_security_parameters();
                break;
            case "edns-disabled" : $this->get_edns_parameters();
                break;

            default: break;
        }
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
        $this->_out = [];
        // extract common variables
        $this->common_data();
        // get the paramters based on dns type
        $this->get_paratmers_with_type();
        //
        //var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getDnsDdata($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  0 => string 'Mar' (length=3)
  1 => string '31' (length=2)
  2 => string '23:59:59' (length=8)
  3 => string 'intdns1' (length=7)
  4 => string 'named[7515]:' (length=12)
  5 => string 'queries:' (length=8)
  6 => string 'info:' (length=5)
  7 => string 'client' (length=6)
  8 => string '@0x7f64ec195d88' (length=15)
  9 => string '10.1.1.62#34390' (length=15)
  10 => string '(osce14-en-census.trendmicro.com):' (length=34)
  11 => string '
query:' (length=8)
  12 => string 'osce14-en-census.trendmicro.com' (length=31)
  13 => string 'IN' (length=2)
  14 => string 'A' (length=1)
  15 => string '+' (length=1)
  16 => string '(10.1.1.9)' (length=10) 
 
 */

/**
 dnssec
 array (size=13)
  0 => string 'Mar' (length=3)
  1 => string '31' (length=2)
  2 => string '23:59:48' (length=8)
  3 => string 'intdns1' (length=7)
  4 => string 'named[7515]:' (length=12)
  5 => string 'dnssec:' (length=7)
  6 => string 'info:' (length=5)
  7 => string 'validating' (length=10)
  8 => string 'iopb.res.in/A:' (length=14)
  9 => string 'no' (length=2)
  10 => string 'valid' (length=5)
  11 => string 'signature' (length=9)
  12 => string 'found' (length=5) 
 * 
 */

/**
 resolver
   0 => string 'Mar' (length=3)
  1 => string '31' (length=2)
  2 => string '23:59:22' (length=8)
  3 => string 'intdns1' (length=7)
  4 => string 'named[7515]:' (length=12)
  5 => string 'resolver:' (length=9)
  6 => string 'info:' (length=5)
  7 => string 'resolver' (length=8)
  8 => string 'priming' (length=7)
  9 => string 'query' (length=5)
  10 => string 'complete' (length=8)
 * 
 * 
 */