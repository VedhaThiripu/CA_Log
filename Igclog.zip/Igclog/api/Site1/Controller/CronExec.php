<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Controller;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;

//
use Site\Helpers\TableHelpers as Table;
use Site\Helpers\LogAddHelper as LogHelper;

/**
 * Description of CronExec
 *
 * @author 91939
 */
class CronExec Extends Controller {

    CONST CRON_SCHEMA = "log__cron_table";
    //put your code here

    private $_log_files = [
        "10.1.1.1" => [
          //  "DNS" => "intdns1/dns-rs1.log.2023-04-01",
          //  "AUDIT" => "intdns1/audit.log.1",
            "CRON" => "intdns1/cron-20230409",
            //"MSG" => "intdns1/messages-20230409"
        ]
    ];
    
    //
    private $_base_path = "C:/Users/91939/Downloads/Log Files/Anusiya IGCAR";
    
    /**
     * 
     * @param type $server
     * @param type $cat
     * @param type $path
     */
    private function insert_cron($server,$cat,$path) {
        $data_in = [
            "server_name"=>$server,
            "log_type"=>$cat,
            "log_path"=>$path
        ];
        $columns = ["server_name","log_type","log_path","start_time"];
        $model = new Model(self::CRON_SCHEMA);
        $model->Columns($columns);
        $out = $model->insertwithdata($data_in);
        return isset($out["id"]) ? $out["id"] : 0;
    }
    
    private function update_cron($id,$status,$msg,$log_count){
        $data_in = [
            "status"=>$status,
            "msg"=>$msg,
            "log_count"=>$log_count
        ];
        $columns = ["status","msg","log_count","end_time"];
        $model = new Model(self::CRON_SCHEMA);
        $model->Columns($columns);
        $model->update($data_in, $id);
    }
    
    // 
    private function get_last_count($server_name,$log_type) {
        $model = new Model();
        $sql = "server_name=:server_name AND log_type=:log_type ORDER BY end_time DESC";
        $select =["log_count"];
        $data = $model->Select($select)->From(Table::CRON_TABLE)->Where($sql)->One()->getDataFull(
                ["server_name"=>$server_name,"log_type"=>$log_type]);
        //var_dump($data);
        return isset($data->log_count) ? $data->log_count : 0;
    }
    
    //
    private function check_log_file_readable($id,$log_path,$last_count) {
        if(!file_exists($log_path) && is_file($log_path)){
            $this->update_cron($id, 2, "File Not Available", $last_count);
            return false;
        }
        if(!is_readable($log_path)){
            $this->update_cron($id, 2, "File Not Readable", $last_count);
            return false;
        }
        //
        return true;
    }
  
    private function process_single_log($id,$log_file,$log_count,$log_cat) {
        $log_handle = fopen($log_file, 'r');
        $i = 0;
        $j = 0;
        $line = "";
        $total_count = defined('TOTAL_CRON_COUNT') ?  TOTAL_CRON_COUNT : 0; 
        while (!feof($log_handle)) {
            $line = fgets($log_handle);
            if($i > $log_count){
                //echo "i = " . $i ."  C = " . $log_count . "<br/>";
                LogHelper::extract_line_insert($line, $log_cat, 0);
                //
                $j ++;
                if($total_count!=0 && $j > $total_count){
                    break;                    
                }
            }
            //
            $i++;           
        }
        fclose($log_handle);
        // update the cron log table
        if($j > 0){
          $this->update_cron($id, 1, "success", ($log_count + $j));
        }else{
            $this->update_cron($id, 2, "No Lines to Read", ($log_count)); 
        }
    }


    //
    private function process_logs($server,$logs) {
        foreach($logs as $log_cat=>$log_path){
            // get last count
            $last_count = $this->get_last_count($server, $log_cat);
            //
           // $full_log_path = $this->_base_path . DS . $log_path;
            //
            $full_log_path = $log_path;
            // get insert_id 
            $log_id = $this->insert_cron($server, $log_cat, $full_log_path);
            // process the log file
            $check_flag = $this->check_log_file_readable($log_id, $full_log_path,$last_count);
            //
            if($check_flag===true){
                $this->process_single_log($log_id, $full_log_path, $last_count,$log_cat);
            }
        }
    }
    
     private function process_logs_db($obj) {        
            $server = $obj->server_name;
            $log_cat = $obj->log_type;
            // get last count
            $last_count = $this->get_last_count($server, $log_cat);
            //
           // $full_log_path = $this->_base_path . DS . $log_path;
            //
            $full_log_path = $obj->log_path;
            // get insert_id 
            $log_id = $this->insert_cron($server, $log_cat, $full_log_path);
            // process the log file
            $check_flag = $this->check_log_file_readable($log_id, $full_log_path,$last_count);
            //
            if($check_flag===true){
                $this->process_single_log($log_id, $full_log_path, $last_count,$log_cat);
            }
        
    }
    
    
    private function get_active_crons() {  
        $sql = "status=1";
        $model = new Model();
        $data = $model->From(Table::CRON_FILES)
                ->Where($sql)
                ->getDataFull([]);
        return $data;    
    }
    

    //
    public function add_log() {
        $this->checkRequestType();
        //
        /*
        foreach($this->_log_files as $server=>$logs){
            $this->process_logs($server, $logs);
        }
         * /
         */
        // get active logs
        $active_logs = $this->get_active_crons();
        foreach($active_logs as $log_data){
            $this->process_logs_db($log_data);
        }
        
        
        //
        $out = new \stdClass();
        $out->msg = "completed";
        $this->succeess_output($out);
    }

}
