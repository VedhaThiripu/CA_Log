<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

use Core\Helpers\Model as Model;
// site helpers
use Site\Helpers\TableHelpers as Table;

class CronLogHelper {

    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $month = $this->get_value(0);
        $month_number = date("n", strtotime($month));
        $day = $this->get_value(2);
        $time = $this->get_value(3);
        $year = date("Y");
        return [$year . "-" . $month_number . "-" . $day, $time];
    }

    private function get_job() {
        $job_str = $this->get_value(5);
        if (strpos($job_str, "anacron") !== FALSE) {
            $this->_out["job"] = "ANACRON";
        } else if (strpos($job_str, "run-parts") !== FALSE) {
            $this->_out["job"] = "RUN-PARTS";
        } else if (strpos($job_str, "CROND") !== FALSE) {
            $this->_out["job"] = "CROND";
        }
    }

    private function common_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->get_job();
        $this->_out["server_name"] = $this->get_value(4);
        //      
    }

    private function get_anacron_parameters() {
        $string = $this->get_value(5);
        $pattern = '/\[(.*?)\]/';
        $matches = [];
        preg_match($pattern, $string, $matches);
        $this->_out["job_type"] = "";
        $this->_out["jobid"] = isset($matches[1]) ? $matches[1] : "";
        $this->_out["user"] = "";
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["command"] = implode(" ", $msg_arr);
    }

    private function get_runparts_parameters() {
        $string = $this->get_value(5);
        $pattern = '/\((.*?)\)\[(.*?)\]/';
        $matches = [];
        preg_match($pattern, $string, $matches);
        //var_dump($matches);
        $this->_out["job_type"] = isset($matches[1]) ? $matches[1] : "";
        $this->_out["jobid"] = isset($matches[2]) ? $matches[2] : "";
        $this->_out["user"] = "";
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["command"] = implode(" ", $msg_arr);
    }

    private function get_crond_parameters() {
        $string = $this->get_value(5);
        $pattern = '/\[(.*?)\]/';
        $matches = [];
        preg_match($pattern, $string, $matches);
        $this->_out["job_type"] = "";
        $this->_out["jobid"] = isset($matches[1]) ? $matches[1] : "";
        $this->_out["user"] = str_replace("(", "", str_replace(")", "", $this->get_value(6)));
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["command"] = implode(" ", $msg_arr);
    }

    /**
     * 
     */
    private function get_paratmers_with_type() {
        switch ($this->_out["job"]) {
            case "ANACRON": $this->get_anacron_parameters();
                break;
            case "RUN-PARTS": $this->get_runparts_parameters();
                break;
            case "CROND" : $this->get_crond_parameters();
                break;
            default: break;
        }
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
        $this->_out = [];
         // common data 
        $this->common_data();
        if(isset($this->_out["job"])){
        // other data with job type
        $this->get_paratmers_with_type();        
        // return 
        return $this->_out;
        }else{
            return [];
        }
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

    /**
     * 
     * @param type $sql
     * @param type $data_in
     * @param type $select
     * @param type $count
     * @return type
     */
    static public function get_all($sql, $data_in = [], $select = [], $count = false) {
        $model = new Model();
        if (count($select) > 0) {
            $model->Select($select);
        }
        $model->From(Table::CRON);
        $model->Where($sql);
        if ($count === true) {
            $model->One();
        }
        $data = $model->getDataFull($data_in);
        return $data;
    }

}

/*
 array (size=8)
  0 => string 'Apr' (length=3)
  1 => string '' (length=0)
  2 => string '2' (length=1)
  3 => string '03:50:02' (length=8)
  4 => string 'intdns1' (length=7)
  5 => string 'run-parts(/etc/cron.daily)[19301]:' (length=34)
  6 => string 'finished' (length=8)
  7 => string 'logrotate' (length=9) 
 
 */

/*
   0 => string 'Apr' (length=3)
  1 => string '' (length=0)
  2 => string '2' (length=1)
  3 => string '04:12:20' (length=8)
  4 => string 'intdns1' (length=7)
  5 => string 'anacron[19286]:' (length=15)
  6 => string 'Job' (length=3)
  7 => string '`cron.daily'' (length=12)
  8 => string 'terminated' (length=10)
  9 => string '(produced' (length=9)
  10 => string 'output)' (length=7)
 */

/*
 array (size=8)
  0 => string 'Apr' (length=3)
  1 => string '' (length=0)
  2 => string '2' (length=1)
  3 => string '04:01:02' (length=8)
  4 => string 'intdns1' (length=7)
  5 => string 'CROND[21346]:' (length=13)
  6 => string '(root)' (length=6)
  7 => string 'CMD' (length=3)
  8 => string '(run-parts' (length=10)
  9 => string '/etc/cron.hourly)' (length=17)
 */