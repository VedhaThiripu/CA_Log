<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
* Database configuration settings
* username , password ,  databasename ,  Host address
*/
// MYSQL host address: default is local host and if the database is on another server 
// use ip address or dns entry of the server
define("DB_HOST", "localhost");
// mysql user name 
define("DB_USER", "root");
// mysql password
define("DB_PASS", "");
// database name
define("DB_NAME", "igclog");
// port
define("DB_PORT",3306);

/**
 *  site settings 
 * 
 */
define("SITEDIR","igclog");
// data directory
define("DATA","/data/");


// Developement Settings 
define("FRAME_DEBUG",TRUE);
// basic core path 
define("CORE_CODE_PATH","core");
//
define("SITE_CODE_PATH","site");
// directory sepearatior
define("DS","/");

// Totoal count
define("TOTAL_COUNT",200000);
// log files line read maximum count in cron job :zero indicates end of the log
define("TOTAL_CRON_COUNT",0);

