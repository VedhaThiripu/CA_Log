<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */
namespace Cron;
/**
 * Description of Cron
 *
 * @author SUBBA RAJU
 */
class CronService {
    //put your code here
    
    static public function exec(){
        // cron sertvber for helper
        HelpQuery::escalate_query();
    }
    
}
