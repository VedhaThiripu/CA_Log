<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
* Database configuration settings
* username , password ,  databasename ,  Host address
*/
// MYSQL host address: default is local host and if the database is on another server 
// use ip address or dns entry of the server
define("DB_HOST", "localhost");
// mysql user name 
define("DB_USER", "root");
// mysql password
define("DB_PASS", "rootvm@kms");
// database name
define("DB_NAME", "igcarcanew");

/**
 *  site settings 
 * 
 */
define("SITEDIR","canew");
// data directory
define("DATA","/var/www/html/canew/data/");


// Developement Settings 
define("FRAME_DEBUG",TRUE);
// basic core path 
define("CORE_CODE_PATH","core");
//
define("SITE_CODE_PATH","site");
// directory sepearatior
define("DS","/");
