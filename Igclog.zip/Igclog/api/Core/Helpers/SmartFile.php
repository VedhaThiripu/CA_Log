<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of SmartFile
 *
 * @author kms
 */
class SmartFile {

    //const DS = "/";

    private $_files;
    private $_tabname;
    private $_colname;
    private $_id;
    //
    private $_single_file;

    static public function combinepdf($input_files, $output_file) {
        $out_files = [];
        foreach ($input_files as $pdffileloc) {
            if (file_exists($pdffileloc)) {
                $out_files[] = $pdffileloc;
            }
        }
        $outfile = $output_file;
        $cmd      = "export HOME=/tmp && pdftk " . implode(" ", $out_files) . " cat output " . $outfile . " 2>&1";
       // echo $cmd;
        shell_exec($cmd);
    }

    /**
     * 
     * @param type $path
     * @return type
     */
    static public function getExt($path) {
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        if (str_getcsv(trim($ext)) > 1) {
            return $ext;
        } else {
            return NULL;
        }
    }

    /**
     * 
     * @param type $dirpath
     */
    static public function createDirectories($dirpath) {
        $str = explode("/", $dirpath);
        // var_dump($str);
        $dir = '';
        foreach ($str as $dpath) {
            $ext = self::getExt($dpath);
            //  echo "ext".$dpath." - ".$ext."<br/>";
            if (strlen($ext) < 1) {
                $dir .= "/" . $dpath;
                if (!file_exists($dir)) {
                    mkdir($dir);
                }
            }
        }
    }

    /**
     * 
     * @param type $table
     * @param type $id
     */
    function __construct($table = "", $id = 0) {
        $this->_tabname = $table;
        $this->_id      = $id;
    }

    /**
     * 
     * @param type $files
     */
    public function processMulti($files) {
        // 
        foreach ($files as $colname => $file) {
            // process the file
            $this->processSingle($file, $colname);
        }
    }

    /**
     * 
     * @param type $file
     */
    public function processSingle($file, $colname) {
        //var_dump($file);
        $this->_single_file = $file;
        //var_dump($this->_single_file);
        $this->_colname     = $colname;
        //
        $newfile            = isset($this->_single_file->newfile) && $this->_single_file->newfile === 1 ? true : false;
        // get the file path 
        $filePath           = $newfile === true ? $this->get_new_file_path() : $this->getFilePath();
       // echo $filePath;
        if (strlen($filePath) > 3) {
            $fullPath = DATA . $filePath;
            //  echo $fullPath;
            // create recuurent directoies if it exsits 
            self::createDirectories($fullPath);
            // check for new or old file 
            if (isset($this->_single_file->newfile) && $this->_single_file->newfile === 1) {
                //  echo "Entered in new mode";
                $this->moveTheFileNew($fullPath);
            } else {
                // echo "Entered in old mode";
                //  move the file
                $baseName = $this->moveTheFile($fullPath);
                // update the table with base name specified
                $this->updateTable($baseName);
            }
            //
        } else {
            \CustomErrorHandler::triger_error("Invalid File Path=" . $filePath);
        }
    }

    /**
     * 
     * @param type $path
     * @return boolean
     */
    private function moveTheFile($path) {
        $tempName = isset($this->_single_file->file["tmp_name"]) ? $this->_single_file->file["tmp_name"] : "";
        if (is_uploaded_file($tempName)) {
            if (move_uploaded_file($tempName, $path)) {
                return basename($path);
            } else {
                \CustomErrorHandler::triger_error("File Upload Error to the path =" . $path);
                return false;
            }
        } else {
            \CustomErrorHandler::triger_error("File Not Uploaded properly =" . $tempName);
        }
    }

    /**
     * 
     * @param type $path
     */
    private function moveTheFileNew($path) {
        $tempName = isset($this->_single_file->file) ? $this->_single_file->file : "##";
        // echo "Temname = " . $tempName;
        if (file_exists($tempName)) {
            if (rename($tempName, $path)) {
                //unlink($tempName);
            } else {
                 \CustomErrorHandler::triger_error("File Not Uploaded properly =");
            }
        } else {
           \CustomErrorHandler::triger_error("File Not Available" . $tempName);
        }
    }

    /**
     * 
     * @param type $baseName
     */
    private function updateTable($baseName) {
        if (strlen($this->_tabname) > 1 && $this->_id > 0) {
            // do update
            $model                 = new Model();
            $data                  = [];
            $data[$this->_colname] = $baseName;
            $model->UpdateTabName($this->_tabname)->update($data, $this->_id);
        }
    }

    //
    private function get_new_file_path() {
        $basedir  = isset($this->_single_file->basedir) ? $this->_single_file->basedir : "";
        $fileName = isset($this->_single_file->fileName) ? $this->_single_file->fileName : "";
        if (strlen($basedir) > 1 && strlen($fileName) > 1) {
            return $basedir . DS . $this->_id . DS . $fileName;
        }
        return "#";
    }

    private function getFilePath() {
        // check file path propery availble in data 
        if (isset($this->_single_file->filepath)) {
            return $this->_single_file->filepath;
        }
        // file path is not availbale  now construct 
        $basedir  = isset($this->_single_file->basedir) ? $this->_single_file->basedir : "";
        $fileName = isset($this->_single_file->fileName) ? $this->_single_file->fileName : "";

        // echo $basedir . " " . $fileName ;  

        if (strlen($basedir) > 1 && strlen($fileName) > 1) {
            // get the extenstion of the file name specified 
            $fielname = isset($this->_single_file->file["name"]) ? $this->_single_file->file["name"] : "";
            // 
            $ext      = self::getExt($fielname);
            // 
            return $basedir . DS . $this->_id . DS . $fileName . "." . $ext;
        }
    }

}
