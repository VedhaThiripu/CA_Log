<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of Zflog
 *
 * @author subbaraju
 */
class Zflog {
    //put your code here
    public $dir_path;
    // full path
	public $full_path;
        // read or write mode 
        private $_mode="write";
        // module name
        private $_module="general";
        // id of the file
        private $_id=0;
        // get the status
        private $_status;
        //
        private $_role;
        //
        private $_action;
        // get the message
        private $_message;
        // emp
        private $_emp;
        // disable sjax klink
        private $_disable_link = false;
        // 
        private $_last;
    
        /**
         * 
         * @param type $atts
         */
	function __construct($atts)
	{
		// log dir should get from global constants
            $this->dir_path = DATA."/log/";
            // get the mod of log read or write
            $this->_mode = isset($atts["mode"]) ? $atts["mode"] : "write";
            // get the module name 
            $this->_module = isset($atts["mod"]) ? $atts["mod"] : $this->_module;
             // get id of the lof
            $this->_id = isset($atts["id"]) ? intval($atts["id"]) : $this->_id;
            // get the status
            $this->_status = isset($atts["status"]) ? ($atts["status"]) : 0;
            //
            $this->_role = isset($atts["role"]) ? ($atts["role"]) : "";
            //
            $this->_action = isset($atts["action"]) ? ($atts["action"]) : "";
            // get the message
            $this->_message = isset($atts["msg"]) ? ($atts["msg"]) : 0;
            // employee
            $this->_emp = isset($atts["emp"]) ? ($atts["emp"]) : $GLOBALS["UNAME"];
            // disable link
            $this->_disable_link = isset($atts["disable"]) ? true : false;
            // last
            $this->_last = isset($atts["last"]) ?  intval($atts["last"])  : 0;
	}
        
         private function is_base64($s)
          {
               return (bool) preg_match('/^[a-zA-Z0-9\/\r\n+]*={0,2}$/', $s);
          }
        /**
         * 
         * @return $this
         */
	public function create_file()
	{
		// creating the log directory
                $mod_dir=$this->dir_path.$this->_module;
                //echo "mod_dir = " .  $mod_dir;
		if(!file_exists($mod_dir)) mkdir($mod_dir);
                 // creating the log filename
		$total_path=$mod_dir."/".$this->_id.".log";
                //echo "Total Path = " .  $total_path;
                
		if(!file_exists($total_path))
		{
			$file_pointer=fopen($total_path,'w');
			fclose($file_pointer);
		}
		$this->full_path=$total_path;
           return $this;
	}
       /**
        * 
        * @return $this
        */
	public function write_file(){		
            $file_pointer=fopen($this->full_path,'a');
            $role_action = $this->_role . "##" . $this->_action."##1";
            $this->_message = base64_encode($this->_message);
            //$eol = (isset($_SERVER['SHELL'])) ? PHP_EOL : "<br />";
            $log_msg= date("Y-m-d H:i:s").'	'.$this->_emp.'	'.$role_action.'	'. preg_replace('/\v+|\\\r\\\n/Ui','<br/>',$this->_message) . PHP_EOL ;
            fwrite($file_pointer,$log_msg);
            fclose($file_pointer);
             return $this;
	}
    
       /**
        * 
        * @return string
        */
        public function read_log_file(){ 
            
           if(file_exists($this->full_path)){ 
           // loading the file and getting the lines in array
           $lines = file($this->full_path);
           // sort from desending order
           krsort($lines);
           // 
            $out = [];
            foreach($lines as $line){
                $exploded_values = explode("\t",$line);
                $obj = new \stdClass();
                $obj->date_time = isset($exploded_values[0]) ? $exploded_values[0] : "";
                $obj->emp_name = isset($exploded_values[1]) ? $exploded_values[1] : "";
                $role_action = isset($exploded_values[2]) ? $exploded_values[2] : "";
                $encr = 0;
                if(strlen($role_action) > 5){
                    $role_explode =  explode("##",$role_action);
                    $obj->role = isset($role_explode[0]) ? $role_explode[0] : "";
                    $obj->action = isset($role_explode[1]) ? $role_explode[1] : "";
                    $encr = isset($role_explode[2]) ? intval($role_explode[2]) : 0;
                }
                $obj->msg = isset($exploded_values[3]) ? $exploded_values[3] : "";
                if($encr===1){
                     $obj->msg = utf8_encode(base64_decode($obj->msg));
                }
              //  var_dump($obj);
                $out[] = $obj;
           }
           // instalizing the table
           return $out;
           }
        }
        /**
         * 
         * @return type
         */
        public function getMoreLink(){
            $atts = [
                "name" => "Click Here",
                "template"=>"general-log-template",
                "id"=>$this->_id,
                "param"=>"mod=".$this->_module
            
            ];
            $shortcode = '[ajaxlink name="Click Here" template="gen-log-gen" id="'.$this->_id.'" param="mod='.$this->_module.'"]';
            return shotcode::exec($shortcode);
        }
        
        /**
         *  execute the log function
         * 
         * 
         */
        public function execute(){
             //
            $this->create_file();
                
            if($this->_mode === "write"){               
                // exeucte the write log command
                $this->write_file();
            }else{
                // read log file
                return $this->read_log_file();
            }
           // exit();
        }
    
        /**
         * 
         * @param type $atts
         * @param type $content
         * @return type
         */
        public static function log($atts,$content=NULL){
           // create a self object 
            $obj = new self($atts);
            // log file1 
            return $obj->execute();
        }
}
