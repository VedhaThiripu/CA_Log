<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

use Core\Helpers\Session as Session;

/**
 * Description of SmartGLobals
 *
 * @author kms
 */
class SmartGLobals {
    //put your code here
    private $_instance = null;
    
    public static function setGlobals(){
        //
        Session::start();
        // loggin_id
        self::sessionToGlobal("LOGGED_IN");
         // empid
        self::sessionToGlobal("EMPID");
         // icno
        self::sessionToGlobal("ICNO");
         // Email
        self::sessionToGlobal("EMAIL");
        // username
        self::sessionToGlobal("USERNAME");
        //
        self::sessionToGlobal("UNAME");
        // empname 
        self::sessionToGlobal("EMPNAME");
        // user groups 
        self::sessionToGlobal("GROUPS");
        //oerg label
        self::sessionToGlobal("ORGLABEL");
        //
        self::sessionToGlobal("EMP_NAME_DESIG");
        //
        self::sessionToGlobal("EMPDESIG");
        //
        self::sessionToGlobal("GRADE");
        // cdate 
        self::set("CDATE", date("Y-m-d"));
        // cdate normal format 
        self::set("CDATE_NORM",date("d-m-Y"));
        // date and time 
        self::set("CDATETIME",date("Y-m-d H:i:s"));
         // time 
        self::set("CTIME",date("h:i:s"));
       // var_dump($GLOBALS);
    }
    /**
     * 
     * @param type $index
     * @param type $value
     */
    public static function  set($index,$value){
        $GLOBALS[$index] = $value;
    }
    /**
     * 
     * @param type $index
     * @param type $value
     * @return type
     */
    public static function  get($index){
        return isset($GLOBALS[$index]) ? $GLOBALS[$index] : "";
    }
    /**
     * 
     * @param type $index
     */
    public static function sessionToGlobal($index){
        $GLOBALS[$index] = Session::get($index);
    }
    /**
     * 
     * @param type $index
     * @param type $sindex
     */
    public static function sessionToGlobalIndex($index,$sindex){
        $GLOBALS[$index] = Session::get($sindex);
    }
    /**
     * 
     * @param type $index
     * @return type
     */
    public static function  getSession($index){
        return isset($_SESSION[$index]) ? $_SESSION[$index] : "";
    }
    
   
    
    
     public static function get_instance(){
        if(!isset(self::$_instance)){
           self::$_instance = new SmartGLobals();
        }
        return self::$_instance;
    }
}
