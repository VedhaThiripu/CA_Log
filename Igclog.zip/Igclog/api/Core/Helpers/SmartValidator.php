<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Validator
 *
 * @author kms
 */
class SmartValidator {
    //put your code here
    private $_temp_data = [];
    private $_file_data = [];
    private $_errors = [];
    private $_col_name = "";
    private $single_rule = [];
    
    private $_single_cond=[];
    private $_validation_check = true;
    
    //
    private $_validation_value = false;
    private $_validation_args = false;
    private $_validation_msg = false;
    
    private $_value="";
    //
    private $_filevalue=null;
    
    /**
     * 
     * @param type $data
     */
    function __construct($data,$filedata=NULL) {
        // get temp data
        $this->_temp_data = $data;
        //
        $this->_file_data = $filedata;
        // get errors 
        $this->_errors = [];
    }
    /**
     * 
     * @param type $table
     * @param type $unique
     */
    public function check_unique($table,$unique){
        // preparation of sql to check unique ness 
        $where = [];
        $data = [];
        foreach($unique as $column){
            $value = $this->get_value_from_data($column);
        }
    }
    
    // get the value as per given type for post and golbal
    private function get_value_check($type,$param){
        switch($type){
            case "GLOBAL" : return isset($GLOBALS[$param]) ? $GLOBALS[$param] : "";
            case "POST" : return $this->get_value_from_data($param);
            default : return "";
        }
    }
    // get conditon
    private function get_check_cond($comp,$value,$current_value){
      //  echo  "C = " . $comp . "" .$value . "" . $current_value . "<br/>";
        switch($comp){
            case "=" : return $current_value== $value ? true : false;
            case "==" : return intval($current_value)== intval($value) ? true : false;
            case ">" : return $current_value > $value ? true : false;
            case "<" : return $current_value < $value ? true : false;
            case ">=" : return $current_value >= $value ? true : false;
            case "<=" : return $current_value <= $value ? true : false;
            case "in" : return in_array($current_value, $value) ? true : false;
            case "notin" : return !in_array($current_value, $value) ? true : false;
        }
    }
    
    
    private function get_param_check($type){
        $param = isset($this->single_cond["param"]) ? $this->single_cond["param"] : "##";
        $comp = isset($this->single_cond["comp"]) ? $this->single_cond["comp"] : "=";
        $check_value = isset($this->single_cond["value"]) ? $this->single_cond["value"] : "";
        $join = isset($this->single_cond["join"]) ?  $this->single_cond["join"] : null;
        $value = $this->get_value_check($type, $param);
        $check = $this->get_check_cond($comp,$check_value,$value);
       // echo "check = " . $check===true ? 1 : 2;
        if($this->_validation_check!=NULL && $join!==null){
            $this->_validation_check =  $join==="AND" ? $this->_validation_check && $check : $this->_validation_check || $check;
        }else{
            $this->_validation_check =  $check;
        }
    }
    
    private function single_condition_check(){
        $type = isset($this->single_cond["type"]) ? $this->single_cond["type"] : "##";
         switch($type){
            case "GLOBAL": 
            case "POST" : $this->get_param_check($type);
            default : FALSE;
         }      
    }

    public function pre_validate_function($col_name,$pre_cond){
       $this->_validation_check = true;   
         foreach($pre_cond as $this->single_cond){  
            $this->single_condition_check();
             // echo "check = " . $col_name . " === " . $this->_validation_check . " <br/><br/>";            
            if($this->_validation_check===false){
                return $this->_validation_check;
            }
         }
        return $this->_validation_check;
    }
    
    /**
     * 
     * @param type $col_name
     * @param type $valid
     */
    public function validate_single_field($col_name,$valid){
        $this->_col_name = $col_name;
        $this->_value = $this->get_value_from_data($this->_col_name);
        $this->_filevalue = $this->get_value_from_file($this->_col_name);
        //var_dump($valid);
        foreach($valid as $type=>$this->single_rule){   
            
             list($this->_validation_args,$this->_validation_msg) = $this->get_rule_value_and_msg($this->single_rule);
            // echo "colname = " . $this->_col_name . "<br/>";
             //var_dump( $this->_filevalue);
             // to prevent validation when it is not present 
             if($type !=="isNull" && $this->_value===null) { return false; }
             
             if($type!=="isNullFile" && $this->_filevalue===NULL){
               //  return false;
             }
           //  var_dump($valid);
            // echo $this->_col_name . "  ". intval($this->_validation_value) ."   " . intval($this->_value) . "   <br/>";
            switch($type){
                case "isNull" : $this->isNull(); break;
                case "isEmpty" : $this->isEmpty(); break;
                case "isEmail" : $this->isEmail();break;
                case "isInt" : $this->isInt();break;
                case "isFloat" : $this->isFloat();break;
                case "isAlpha" : $this->isAlpha();break;
                case "isAlphanumeric" : $this->isAlphanumeric();break;
                case "lengthBw" : $this->lengthBw(); break;
                case "wordBw" : $this->wordBw(); break;
                case "isIn" :  $this->isIn(); break;
                case "notIn" :  $this->notIn(); break;
                case "isDate" :  $this->isDate(); break;
                case "custom"  : $this->custom(); break;
                case "isNullFile" : $this->isNullFile(); break;
                case "isFile" : $this->isFile(); break;
                case "isFileNew" : $this->isFileNew(); break;
                default : break;
            }
        }
    }
    /**
     * 
     * @return type
     */
    public function getErrors(){
        return $this->_errors;
    }     
    
    private function isNull() {
        if($this->_value===null){
             $this->update_error($this->_validation_msg); 
        }
    }
    private function isEmpty() {
        if(is_array($this->_value) && sizeof($this->_value) <1 ){
             $this->update_error($this->_validation_msg);
        }else if(strlen($this->_value) < 1){
            $this->update_error($this->_validation_msg);
        }
    }
    private function isEmail(){
        
      if(!filter_var($this->_value, FILTER_VALIDATE_EMAIL)){
           $this->update_error($this->_validation_msg); 
      }
    }
    private function isInt(){
      if(!filter_var($this->_value, FILTER_VALIDATE_INT)){
           $this->update_error($this->_validation_msg); 
      }else{
           // now check for limits
           $this->min_max_value_check();  
      }       
    }
     private function isFloat(){
      if(!filter_var($this->_value, FILTER_VALIDATE_FLOAT)){
           $this->update_error($this->_validation_msg); 
      }else{            // now check for limits
          $this->min_max_value_check();   
      }
     
    }
    
    private function isAlphanumeric(){
       if(preg_match('/[^a-z]/i', $this->_value)){
            $this->update_error($this->_validation_msg); 
        }else{
            $this->min_max_length_check();
        }   
    }
    private function isAlpha(){
       if(preg_match('/[^a-z]/i', $this->_value)){
            $this->update_error($this->_validation_msg); 
        }else{
            $this->min_max_length_check();
        }   
    }
    
    private function lengthBw(){
        $this->min_max_length_check();
    }
    private function wordBw(){
      $this-> min_max_word_check();
    }      
    private function isIn(){
        $args = $this->_validation_args;
        if(!in_array($this->_value, $args)){
             $this->update_error($this->_validation_msg); 
        }
    }
    private function notIn(){
       $args = $this->_validation_args;
       if(in_array($this->_value,$args)){
            $this->update_error($this->_validation_msg); 
       }
    }
    
    private function isDate(){
      if(!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$this->_value)){
           $this->update_error($this->_validation_msg); 
      }else{
          $this->min_max_date_check();
      }
    }
    
    private function custom(){
        $args = $this->_validation_args;
        $class_name = isset($args[0]) ? $args[0] :"";
        $function_name = isset($args[1]) ? $args[1] :"";
        if($class_name!="" && $function_name!=""){
            // call the function and the result and update the status
        }
    }
    /**
     * 
     */
    private function isNullFile() {
        if($this->_filevalue===null){
             $this->update_error($this->_validation_msg); 
        }
    }
    
     private function isFile() {
        // var_dump($this->_filevalue);
        //if($this->_filevalue===null) return false;
        // now check other conditions
        $args = $this->_validation_args;
        // check extenstion
        $ext = isset($args["ext"]) ? $args["ext"] : null;
        if($ext!=null){
            $name = isset($this->_filevalue["name"]) ? $this->_filevalue["name"] : null;
            $this->file_extenstion_validation($ext,$name);
        }
        // do size validation
        $size_arr = isset($args["size"]) ? $args["size"] : null;
        if($size_arr!=null){
            $size = isset($this->_filevalue["size"]) ? $this->_filevalue["size"] : 0;
            $this->file_size_validation($size_arr,$size);
        }
    }
    
    private function isFileNew() {
        $actual_file = base64_decode($this->_value);
        //
        //echo "act_file = " . $actual_file;
        // check whether file exists in the location
        if(!file_exists($actual_file)){
             //   echo "entered here";
             $this->update_error($this->_validation_msg);
             return true;
        }        
        
        $args = $this->_validation_args;
        // check extenstion
        $ext = isset($args["ext"]) ? $args["ext"] : null;
        if($ext!=null){
            $this->file_extenstion_validation($ext,$actual_file);
        }
        // do size validation
        $size_arr = isset($args["size"]) ? $args["size"] : null;
        if($size_arr!=null){
            $size = filesize($actual_file) / 100000;
            //echo "size = " . $size;
            $this->file_size_validation($size_arr,$size);
        }
    }
    
    private function file_extenstion_validation($ext,$name){
        //$name = isset($this->_filevalue["name"]) ? $this->_filevalue["name"] : null;
       // var_dump($ext);
        $file_ext = pathinfo($name, PATHINFO_EXTENSION); 
        //echo "file_ext = " . $file_ext;
        if(!in_array(strtolower($file_ext), $ext)){
            $this->update_error("The Uploaded File Extenstion (".$file_ext.") is not Valid: Valid Extenstions " . implode(",",$ext) ); 
        }
    }
    
    private function file_size_validation($size_arr,$size){       
        $min_size = isset($size_arr[0]) ? $size_arr[0] : 0.001;
        $max_size = isset($size_arr[1]) ? $size_arr[1] : 20;
       // echo $size;
        if($size<$min_size || $size > $max_size){
             $this->update_error($this->_validation_msg . " Size should be beween (" . $min_size . " MB, ".$max_size." MB ) "); 
        }
    }
    
    
    private function min_max_value_check() {
        $args = $this->_validation_args;
         if($args!=null){
          $min= isset($args["min"]) ? $args["min"] : 0;
          $max = isset($args["max"]) ? $args["max"] : 0;
          $value = intval($this->_value);
          if($min!=0){
              $this->min_check($min,$value);
          }
          if($max!=0){
              $this->max_check($max,$value);
          }
        } 
    }
    
    
    private function min_check($min,$value){
      if($value < intval($min)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    private function max_check($max,$value){
      if($value > intval($max)){     
           $this->update_error($this->_validation_msg); 
      }
    }

    private function min_max_length_check() {
        $args = $this->_validation_args;
         if($args!=null){
          $min= isset($args["min"]) ? $args["min"] : 0;
          $max = isset($args["max"]) ? $args["max"] : 0;
          $value = strlen($this->_value);
          if($min!=0){
              $this->min_check($min,$value);
          }
          if($max!=0){
              $this->max_check($max,$value);
          }
        } 
    }
    
     private function min_max_word_check() {
        $args = $this->_validation_args;
         if($args!=null){
          $min= isset($args["min"]) ? $args["min"] : 0;
          $max = isset($args["max"]) ? $args["max"] : 0;
          $value = count(explode(" ",$this->_value));
          if($min!=0){
              $this->min_check($min,$value);
          }
          if($max!=0){
              $this->max_check($max,$value);
          }
        } 
    }
    private function min_max_date_check() {
        $args = $this->_validation_args;
         if($args!=null){
          $min= isset($args["min"]) ? $args["min"] : 0;
          $max = isset($args["max"]) ? $args["max"] : 0;
          $value = $this->_value;
          if($min!=0){
              $this->min_check($min,$value);
          }
          if($max!=0){
              $this->max_check($max,$value);
          }
        } 
    }
    

    
    
    
    //filter_var($int, FILTER_VALIDATE_INT))
    
     /**
     * 
     * @param type $rules
     * @return type
     */
    private function get_rule_value_and_msg($rules){
        if(is_array($rules)){
            // rule contains array of msg and arguments 
            $args = isset($rules["args"]) ? $rules["args"] : null;
            $msg = isset($rules["msg"]) ? $rules["msg"] : null;
            return [$args,$msg];
        }else{
            // only msg so return 
            return [null,$rules];
        }
        //var_dump($rules);
        //$rule_value = isset($rules[0]) ? $rules[0] : null;
        //$rule_msg = isset($rules[1]) ? $rules[1] : null;
        //return [$rule_value,$rule_msg];
    }
   /**
    * 
    * @param type $column_name
    * @return type
    */
    private function get_value_from_data($column_name){
        if(isset($this->_temp_data[$column_name])){
            $value = $this->_temp_data[$column_name];
            if(!is_array($value)){
                return trim($value);
            }else{
                return array_filter($value);
            }
        }else{
            return null;
        }
      //  return isset($this->_temp_data[$column_name]) && !is_array($this->_temp_data[$column_name]) ? trim($this->_temp_data[$column_name]) : null;
    }
    
    private function get_value_from_file($column_name){
        //var_dump($this->_file_data);
       if(isset($this->_file_data[$column_name])){
           return $this->_file_data[$column_name];
       }else{
           return null;
       } 
      //  return isset($this->_temp_data[$column_name]) && !is_array($this->_temp_data[$column_name]) ? trim($this->_temp_data[$column_name]) : null;
    }
    
     /**
    * 
    * @param type $col_name
    * @param type $msg
    */
    private function update_error($msg){
        $this->_errors[$this->_col_name] = $msg;
    }
    
    
    
}
