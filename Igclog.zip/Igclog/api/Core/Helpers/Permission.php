<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

use Core\Helpers\SmartGLobals as Globals;

//use Core\

/**
 * Description of Permission
 *
 * @author kms
 */
class Permission {
    //put your code here
    private $_auth_schema = [];
    
    // updatet eh schema 
    public function updateSchema($schema){
        $this->_auth_schema = $schema;
    }
    // check one auth with schema 
    public function check_auth($modname){
        $rules = isset($this->_auth_schema[$modname]) ? $this->_auth_schema[$modname] : [];
        // if not permission allow the module 
        if(empty($rules)){
            return true;
        }        
        // 
        foreach ($rules as $rule_type=>$rule_value){
            $this->check_single_permission($rule_type, $rule_value);
        }
    }
    /**
     * 
     * @param type $rule_type
     * @param type $rule_value
     */
    private function check_single_permission($rule_type,$rule_value){
        switch($rule_type){
            case "loggedin" : $this->check_logged_condition();
                       break;
            case "usergroup" : $this->check_usergroup_condition($rule_value);
                       break;
            case "session" : $this->check_session_condition($rule_value);
                       break;
            default : break;
                        
        }
    }
    /**
     * 
     */
    private function check_logged_condition(){
        $logged_ind = intval(Globals::get("LOGGED_IN"));
        if($logged_ind===0){
            \CustomErrorHandler::handle_authentication_function();
        }
    }
    /**
     * 
     * @param type $groups
     */
    private function check_usergroup_condition($groups){
      $check_groups = !is_array($groups) ? [$groups] : $groups;
      //
      $perm = false;
      //
      foreach($check_groups as $group_name){
          $check_perm = true;
          if($check_perm === true){
              $perm = true;
          }
      }
      // after all the loops the permission is true 
      if($perm ===false){
           \CustomErrorHandler::handle_authentication_function();
      }         
    }
    /**
     * 
     */
     private function check_session_condition(){
        $logged_ind = isset($GLOBALS["logged_in"]) ? intval($GLOBALS["logged_in"]) : 0;
        if($logged_ind===0){
            \CustomErrorHandler::handle_authentication_function();
        }
    }
}
