<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of SmartDsAttach
 *
 * @author SUBBA RAJU
 */
class SmartDsAttach {
    private $_src;
    private $_dest;
    private $_schema;
    private $_settings;
    private $_id;
    private $_json_file;
    private $_out=[];
    private $_imgno = 0;
    /**
     * 
     * @param type $name
     * @param type $width
     * @param type $height
     * @return type
     */
    static public function getSigField($name,$width=200,$height=50){
        return [
            "dstype"=>"SINGLE",
            "stype"=>"SIG",
            "name"=>$name,
            "width"=>$width,
            "height"=>$height,
        ];
    }
    /**
     * 
     * @param type $name
     * @param type $width
     * @param type $height
     * @return type
     */
    static public function getTextField($name,$width=200,$height=50,$fsize=0){
        return [
            "dstype"=>"SINGLE",
            "stype"=>"TEXT",
            "name"=>$name,
            "width"=>$width,
            "height"=>$height,
            "fsize"=>$fsize
        ];
    }
    
    static public function getTextAreaField($name,$width=200,$height=50,$fsize=0){
        return [
            "dstype"=>"SINGLE",
            "stype"=>"MULTITEXT",
            "name"=>$name,
            "width"=>$width,
            "height"=>$height,
            "fsize"=>$fsize
        ];
    }
    
    //put your code here
    static public function execute($schema,$id,$src,$dest){
        $obj = new self();
        $obj->_id = $id;
        $obj->_src = DATA.$src;
        $obj->_dest = DATA.$dest;
        $obj->_schema = $schema;
       //
        return $obj->process();        
    }
    // generate the json file and execute the ds attach function
    private function process(){
        // check src location 
        $this->check_src_location();
        // process the schema 
        $this->process_schema();
        // get the fileds 
        $out = $this->get_digi_object();
        //
        //var_dump($out);
        // save json file
        $this->store_json_file($this->_id,$out);
        //
        
        // execute teh ds attach
        $this->exec_java();
        // check destnation file 
        $this->check_dest_location();
        // return the status
        return true;
    }
    
    private function check_src_location(){
        if(!file_exists($this->_src) || !is_file($this->_src)){
           trigger_error("Source File Does Not Exists in DS Attach: $this->_src ",E_USER_ERROR);  
        }
    }
    
    private function check_dest_location(){
        if(!file_exists($this->_dest)){
           trigger_error("Destination File Has Not Been Created: $this->_dest ",E_USER_ERROR);  
        }
    }
    // process schema
    private function process_schema(){
        if(is_array($this->_schema)){
             // this is added to send the details directly with out schema
          $this->_settings= $this->_schema;
        }else{
        $dir = "Site/schema/dsattach/";
        $file = $dir . $this->_schema .".json";
        if(!file_exists($file)) trigger_error("Schema File Does Not Exists : $this->_schema ",E_USER_ERROR);
        $json_str = file_get_contents($file);
        $json_obj = json_decode($json_str,true);
        $this->_settings = $json_obj;
        }
       // var_dump($this->_settings);
    }


    private function get_digi_object(){
       $obj = new \stdClass();
       $obj->srcloc = $this->_src;
       $obj->destloc = $this->_dest;
       $obj->sig = $this->generate_fileds(); 
       return $obj;
    }
    //
    private function generate_fileds(){
        $this->_out = [];
       // var_dump($this->_settings);
        foreach($this->_settings as $obj){           
            switch($obj["dstype"]){
                case "SINGLE" : $this->single_filed($obj);  break;
               // case "TABLE"  : $this->table_group();    break;
                default:  break;
            } 
        }
        return $this->_out;
    }
    
    private function single_filed($obj) {
        if($obj["stype"]=="NOCOMP"){
            $this->_imgno++;
        }else{
            //var_dump($obj);
        $db = new \stdClass();
        $db->signame = isset($obj["name"]) ? trim($obj["name"]) : "";
        $db->sigwidth = isset($obj["width"]) ? "".$obj["width"] : "100";
        $db->sigheight = isset($obj["height"]) ? "".$obj["height"] : "100";
        $db->texttype = "".$this->get_text_type($obj["stype"]);
        $db->multiline = "".$this->get_multi_line($obj["stype"]);
        $db->fontsize = isset($obj["fsize"]) && intval($obj["fsize"]) > 1 ? "".$obj["fsize"] : "0";
        $db->imgno = "" . $this->_imgno;
        $this->_out[] = $db;
        $this->_imgno++;
        }
    }
    
     private function get_text_type($stype){
        switch($stype){
            case "SIG" : return 1;
            case "TEXT" : return 2;
            case "MULTITEXT" : return 2;
        }
    }
    /**
     * 
     * @param type $stype
     * @return type
     */
    private function get_multi_line($stype){
        return $stype =="MULTITEXT" ? 1 : 0;
    }
    
    
    
    private function store_json_file($id,$outobj){ 
      $empid = isset($GLOBALS["empid"]) ? intval($GLOBALS["empid"]) : 12456;
     // var_dump($empid);
      $rand_number = rand(11111111111,99999999999);
      $filename = is_string($this->_schema) ? $this->_schema : "tempname";
      $this->_json_file = TMP.$filename ."_". $empid. $id.$rand_number.".json";
      try{
        file_put_contents($this->_json_file, json_encode($outobj));
      }catch(Exception $e){
          
      }
    
    }
    
    private function exec_java(){
        $cmd = "../../common/jre8/bin/java -jar ../../common/script/dsattach.jar ".$this->_json_file;
         echo $cmd;
         exec($cmd);
         //
         unlink($this->_json_file);
        //var_dump($out);
    }
    
}
