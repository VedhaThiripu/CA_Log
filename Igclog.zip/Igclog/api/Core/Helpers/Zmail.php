<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of Zmail
 *
 * @author SUBBA RAJU
 */
class Zmail {
    private $mail;
    private $_error=0;
    private $_errmsg = "";
    private $output= [];
    
     // log variables 
    private $_modname;
    private $_logpath="";
    private $_logime="";
    private $_loguser="";
    private $_toemails;
    private $_ccemails;
    private $_msg; 
    
    private $_zldap;
    //
    //private $from;
    //put your code here
    private function get_mail_object(){
             require '../../common/mail/PHPMailer.php';
           require '../../common/mail/SMTP.php';
           $mail = new \PHPMailer(true);
           $mail->SMTPDebug = \SMTP::DEBUG_SERVER;                      // Enable verbose debug output
           $mail->isSMTP();                                            // Send using SMTP
           $mail->Host       = MAIL_HOST;                    // Set the SMTP server to send through
           $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
           $mail->Username   = MAIL_UNAME;                     // SMTP username
           $mail->Password   = MAIL_PASS;                               // SMTP password
           $mail->SMTPSecure = '';//PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
           $mail->Port       = MAIL_PORT;
           $mail->Debugoutput = function($str, $level) {
                $this->output[]= "$level: $str";
            };
           return $mail;  
    }
    
    function __construct($modulename="test") {
        $this->mail = $this->get_mail_object();
       
        $this->mail->Subject = "";
        $this->mail->Body = "";  
        
        $this->_modname = $modulename;
        $this->_logpath =  DATA."log/sysMailLog/";
        $this->_logime = date("Y-m-d H:i:s");
        $this->_loguser = SmartGLobals::get("EMPID"); // loggin user  
        
        $this->_zldap = new Zldap();
    }
    
    public function getEmailFromUname($uname){
        $empid = General::getEmpid($uname);
       // echo "empid = " . $empid;
        $email = $this->_zldap->getEmail($empid);
        if (strpos($email, '@') !== false){
            return $email; 
        }
        return null;
    }
    
    public function From($from,$fromname){
        try{
          $this->mail->setFrom($from, $fromname);
        }catch(Exception $e){
            
        }
        return $this;
    }
    public function Subject($subject){
        $this->mail->Subject = $subject;
        return $this;
    }
    public function Message($message){
        $this->_msg = $message;
        $this->mail->isHTML(true);
        $this->mail->Body = $message;
        return $this;
    }
    public function To($emails){
       //$this->_toemails = $emails;
       foreach($emails as $emaild){   
         if (strpos($emaild, '@') !== false){
             $this->mail->addAddress($emaild);
             $this->_toemails[] = $emaild;
         }else{
             $emailnew = $this->getEmailFromUname($emaild);
            // echo $emaild ."  " . $emailnew . "<br/>";
             if($emailnew!=null){
              //   $this->mail->addAddress($emailnew);
                  $this->mail->addAddress("subbaraju@igcar.gov.in");
                  $this->_toemails[] = [$emailnew,$emaild];
             }
         } 
       }
       return $this;
    }
    public function Cc($emails){
       // $this->_ccemails = $emails;
       foreach($emails as $emaild){   
         if (strpos($emaild, '@') !== false){
             $this->mail->addCC($emaild);
             $this->_ccemails[] = $emaild;
         }else{
             $emailnew = $this->getEmailFromUname($emaild);
             if($emailnew!=null){
                // $this->mail->addCC($emailnew);
                 $this->_ccemails[] = [$emailnew,$emaild];
             }
         }  
       }
       return $this;
    }
    public function Bcc($emails){
       foreach($emails as $emaild){   
         if (strpos($emaild, '@') !== false){
             //$this->mail->addBCC($emaild);
             //$this->_bccemails[] = $emaild;
         } 
       }
       return $this;
    }
    
    public function Attach($files){
      foreach($files as $fileloc=>$filename){
        if(file_exists($fileloc)){
             // $filename = basename($fileloc);
             $this->mail->addAttachment($fileloc,$filename);
            }                 
       }
       return $this;
    }
    // 
    public function ReplyTo($replyto){
        $this->mail->addReplyTo($replyto, $replyto);
        return $this;
    }
    // sending mail
    public function Send(){ 
        try{       
          // $this->mail->send();         
           $this->write_log_file();
           return true;
        }catch(\Exception $e) {
            $this->_error = 1;
            $this->_errmsg = $e->getMessage();
            $this->write_log_file();         
            return false; 
        }         
    }
    
    // prepare the log message to be stored 
    private function prepare_log_message(){
        $db =new \stdClass();
        $db->modname = $this->_modname;
        $db->datetime = $this->_logime;
        $db->status = $this->_error;
        $db->errormsg = $this->_errmsg;
        $db->user = $this->_loguser;
        $db->subject = $this->mail->Subject;
        $db->toemail = $this->_toemails;
        $db->ccemail = $this->_ccemails;
        $db->message = $this->_msg;
        $db->output = $this->output;
        return json_encode($db);
    }
    // preparing the log message
    private function prepare_log_file(){
        if(!file_exists( $this->_logpath)) { mkdir( $this->_logpath);}
        $logpath = $this->_logpath . date("Y-m-d") . ".log";
        return $logpath;
    }
    // 
    private function write_log_file(){
        $logfile = $this->prepare_log_file();
        $message = $this->prepare_log_message(); 
        $file_pointer=fopen($logfile,'a');
        fwrite($file_pointer,$message . PHP_EOL);
        fclose($file_pointer); 
    }
    
    
            
    
    
    
    
}
