<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of ZfileDownload
 *
 * @author SUBBA RAJU
 */
class Zfile {

    //put your code here
    static public function DownloadFile($path) {
        // get the basename
        $basename = basename($path);
        // get the extenstion
        $ext      = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        //
        if (file_exists($path)) {
            switch ($ext) {
                case 'pdf' : self::showPdf($path, $basename);
                    break;
                default: self::download($path,$basename);                 
                    break;
            }
        } else {
            echo "file not found " . $path;
        }
    }

    /**
     * 
     * @param type $path
     * @param type $basename
     */
    static private function showPdf($path, $basename) {
        ob_clean();
        header('Content-type: application/pdf');
        header('Content-Disposition: inline; filename=' . $basename . '');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($path));
        @readfile($path);
        exit();
    }
    
    static private function download($path,$basename) {
		//echo $path;		
        ob_clean();
        header('Content-type: application/octet-stream');
        header('Content-Disposition: inline; filename=' . $basename . '');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($path));
        @readfile($path);
	  
    }

}
