<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Core\Helpers;

/**
 * Description of General
 *
 * @author SUBBA RAJU
 */
class General {
    //put your code here

    /**
     * 
     * @param type $width
     * @param type $height
     * @return type
     */
    static public function dsimage($width = 200, $height = 50) {
        return "<img src='../../common/digsig.jpg' width='" . $width . "' height='" . $height . "' alt='Digital Signature'/>";
    }

    /**
     * 
     * @param type $input
     * @return type
     */
    static public function encode($input) {
        return base64_encode($input);
    }

    /**
     * 
     * @param type $input
     * @return type
     */
    static public function decode($input) {
        return base64_decode($input);
    }

    /**
     * 
     * @param type $input
     * @return type
     */
    static public function removeEmpid($input) {
        $name = preg_replace("/[0-9]+/", "", $input);
        return str_replace(")", "", str_replace("(", "", $name));
    }

    /**/

    static public function getEmpid($input) {
        $empid = preg_replace("/[^0-9]/", "", $input);
        return $empid;
    }

    /**
     * 
     * @param type $input
     * @return type
     */
    static public function removeNonAlphaNumeric($input) {
        $name = preg_replace("/[A-Za-z0-9]+/", "", $input);
        return str_replace(")", "", str_replace("(", "", $name));
    }

    /**
     * 
     * @return type
     */
    static public function getCurrentDateDisp() {
        return date("d/m/Y");
    }

    /**
     * 
     * @return type
     */
    static public function getCurrentYearDisp() {
        return date("Y");
    }

    static public function check_date($date,$format = 'Y-m-d') {
        $d = \DateTime::createFromFormat($format, $date);
        // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
        return $d && $d->format($format) === $date;
    }

    static public function chageDate($date, $format = "d-m-Y") {
        if (self::check_date($date) == false) {
            return $date;
        }
        return date($format, strtotime($date));
    }

    /**
     * 
     * @param type $table_name
     * @param type $id
     * @param type $columns
     * @return type
     */
    static public function getSingleData($table_name, $id, $columns = ["*"]) {
        $model = new Model();
        $data  = $model->Select($columns)
                ->From($table_name)
                ->Where("ID=:ID")
                ->One()
                ->getDataFull(["ID" => $id]);

        if (sizeof($columns) === 1 && is_string($columns[0]) && $columns[0] !== "*") {
            $column_name = $columns[0];
            // suppose if the columns is ["indent_id"] as in input
            // asume the data from database is { ID:1,indent_id:"12"}
            // $data->indent_id is set then return $data->indemnt_id 
            return isset($data->$column_name) ? $data->$column_name : "";
        } else {
            // this is an object with all the columns as properties 
            // ex : { ID:1,fileno:"DPS/MRPU/01/01/469"}
            return $data;
        }
    }

    /**
     * 
     * @param type $path
     */
    static public function removeFile($path) {
        $file_path = DATA . $path;
        if (file_exists($file_path) && is_file($file_path)) {
            unlink($file_path);
        }
    }

    /**
     * 
     * @param type $value
     * @param type $label
     * @return \stdClass
     */
    static public function getSelectObject($value, $label = null) {
        $db        = new \stdClass();
        $db->value = $value;
        $db->label = $label === null ? $value : $label;
        return $db;
    }

    /**
     * 
     * @param type $number
     * @return type
     */
    static public function getIndianCurrencyWords($number) {
        $decimal       = round($number - ($no            = floor($number)), 2) * 100;
        $hundred       = null;
        $digits_length = strlen($no);
        $i             = 0;
        $str           = array();
        $words         = array(0 => '', 1 => 'one', 2 => 'two',
            3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
            7 => 'seven', 8 => 'eight', 9 => 'nine',
            10 => 'ten', 11 => 'eleven', 12 => 'twelve',
            13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
            19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
            40 => 'forty', 50 => 'fifty', 60 => 'sixty',
            70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits        = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_length) {
            $divider = ($i == 2) ? 10 : 100;
            $number  = floor($no % $divider);
            $no      = floor($no / $divider);
            $i       += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural  = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str []  = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
            } else
                $str[] = null;
        }
        $Rupees = (implode('', array_reverse($str)));
        $paise  = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        $res    = ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
        return strtoupper($res);
    }

    static public function hideEmailAddress($email) {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            list($first, $last) = explode('@', $email);
            $first            = str_replace(substr($first, '3'), str_repeat('*', strlen($first) - 3), $first);
            $last             = explode('.', $last);
            $last_domain      = str_replace(substr($last['0'], '1'), str_repeat('*', strlen($last['0']) - 1), $last['0']);
            $hideEmailAddress = $first . '@' . $last_domain . '.' . $last['1'];
            return $hideEmailAddress;
        }
    }

}
