-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2023 at 05:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `igclog`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log_table`
--

CREATE TABLE `audit_log_table` (
  `ID` int(11) NOT NULL,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) DEFAULT NULL,
  `type` varchar(25) NOT NULL,
  `deamon_id` int(11) DEFAULT NULL,
  `cmd` text NOT NULL,
  `arch` varchar(255) DEFAULT NULL,
  `syscall` varchar(255) DEFAULT NULL,
  `success` varchar(255) DEFAULT NULL,
  `exit_code` varchar(255) DEFAULT NULL,
  `a0` varchar(255) DEFAULT NULL,
  `a1` varchar(255) DEFAULT NULL,
  `a2` varchar(255) DEFAULT NULL,
  `a3` varchar(255) DEFAULT NULL,
  `items` varchar(255) DEFAULT NULL,
  `ppid` varchar(255) DEFAULT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `auid` varchar(255) DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `euid` varchar(255) DEFAULT NULL,
  `suid` int(11) DEFAULT 0,
  `fsuid` int(11) DEFAULT 0,
  `egid` int(11) DEFAULT 0,
  `sgid` int(11) DEFAULT 0,
  `fsgid` int(11) DEFAULT 0,
  `tty` varchar(255) DEFAULT NULL,
  `ses` varchar(255) DEFAULT '0',
  `comm` varchar(1000) DEFAULT NULL,
  `exe` varchar(1000) DEFAULT NULL,
  `msg` text DEFAULT NULL,
  `key_file` varchar(255) DEFAULT NULL,
  `item` varchar(15) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inode` varchar(15) DEFAULT NULL,
  `dev` varchar(10) DEFAULT NULL,
  `mode` varchar(25) DEFAULT NULL,
  `ouid` int(11) NOT NULL DEFAULT 0,
  `ogid` int(11) NOT NULL DEFAULT 0,
  `rdev` varchar(25) DEFAULT NULL,
  `objtype` varchar(255) DEFAULT NULL,
  `cap_fp` varchar(50) DEFAULT NULL,
  `cap_fi` varchar(50) DEFAULT NULL,
  `cap_fe` int(11) DEFAULT 0,
  `cap_fver` int(11) NOT NULL DEFAULT 0,
  `grantors` varchar(255) DEFAULT NULL,
  `acct` varchar(255) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `terminal` varchar(255) DEFAULT NULL,
  `res` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cron_files`
--

CREATE TABLE `cron_files` (
  `ID` int(11) NOT NULL,
  `server_name` varchar(200) NOT NULL,
  `log_type` varchar(10) NOT NULL,
  `log_path` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `cdatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cron_log_table`
--

CREATE TABLE `cron_log_table` (
  `ID` int(11) NOT NULL,
  `infotable_id` int(11) NOT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `jobname` varchar(1000) NOT NULL,
  `server_name` varchar(100) DEFAULT NULL,
  `job` varchar(60) DEFAULT NULL,
  `job_type` varchar(300) DEFAULT NULL,
  `jobid` int(11) DEFAULT NULL,
  `user` varchar(25) DEFAULT NULL,
  `command` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cron_table`
--

CREATE TABLE `cron_table` (
  `ID` int(11) NOT NULL,
  `server_name` varchar(30) DEFAULT NULL,
  `log_type` varchar(20) NOT NULL,
  `log_path` varchar(512) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `log_count` double NOT NULL DEFAULT 0,
  `msg` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dns_log_table`
--

CREATE TABLE `dns_log_table` (
  `ID` int(11) NOT NULL,
  `infotable_id` int(11) NOT NULL,
  `cdate` date DEFAULT NULL,
  `ctime` varchar(10) DEFAULT NULL,
  `qry_type` varchar(60) DEFAULT NULL,
  `server_name` varchar(1000) DEFAULT NULL,
  `daemon` varchar(255) DEFAULT NULL,
  `qry_lvl` varchar(50) DEFAULT NULL,
  `client_ip` varchar(255) DEFAULT NULL,
  `client_port` int(11) NOT NULL DEFAULT 0,
  `client_name` varchar(255) DEFAULT NULL,
  `domain_name` varchar(255) DEFAULT NULL,
  `record_type` varchar(255) DEFAULT NULL,
  `domain_ip` varchar(255) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infotable`
--

CREATE TABLE `infotable` (
  `ID` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `file_path` varchar(1000) NOT NULL,
  `created_time` datetime NOT NULL,
  `created_by` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages_log_table`
--

CREATE TABLE `messages_log_table` (
  `ID` int(11) NOT NULL,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `subtype` varchar(50) DEFAULT NULL,
  `software` varchar(50) DEFAULT NULL,
  `swVersion` varchar(50) DEFAULT NULL,
  `x_pid` varchar(50) DEFAULT NULL,
  `x_info` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `msg` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log_table`
--
ALTER TABLE `audit_log_table`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `server_name` (`server_name`),
  ADD KEY `cdate` (`cdate`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `cron_files`
--
ALTER TABLE `cron_files`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cron_log_table`
--
ALTER TABLE `cron_log_table`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `cdate` (`cdate`),
  ADD KEY `server_name` (`server_name`),
  ADD KEY `job` (`job`);

--
-- Indexes for table `cron_table`
--
ALTER TABLE `cron_table`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `dns_log_table`
--
ALTER TABLE `dns_log_table`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `qry_type` (`qry_type`),
  ADD KEY `cdate` (`cdate`),
  ADD KEY `server_name` (`server_name`);

--
-- Indexes for table `infotable`
--
ALTER TABLE `infotable`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `messages_log_table`
--
ALTER TABLE `messages_log_table`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `server_name` (`server_name`),
  ADD KEY `cdate` (`cdate`),
  ADD KEY `type` (`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log_table`
--
ALTER TABLE `audit_log_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cron_files`
--
ALTER TABLE `cron_files`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cron_log_table`
--
ALTER TABLE `cron_log_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cron_table`
--
ALTER TABLE `cron_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dns_log_table`
--
ALTER TABLE `dns_log_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `infotable`
--
ALTER TABLE `infotable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages_log_table`
--
ALTER TABLE `messages_log_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
